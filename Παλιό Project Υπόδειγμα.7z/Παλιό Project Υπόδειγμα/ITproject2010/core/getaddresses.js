function  getaddress(){
	var xmlhttp;
	if (window.XMLHttpRequest){
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	} 
	else if (window.ActiveXObject){ // code for IE6, IE5.  
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	else {
		alert("Your browser does not support XMLHTTP!");
	}
		var qstr="?do=getaddresses";
		var url_="api.php"+qstr;
		xmlhttp.open("GET",url_,true);
		xmlhttp.onreadystatechange=function() {};
		xmlhttp.send(null);
	//alert('hey');
	setTimeout("getaddress()",3000);
}

getaddress();