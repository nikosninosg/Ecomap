<?php
$db_info["host"] = "localhost";
$db_info["username"] = "root";
$db_info["password"] = "";
$db_info["database"] = "first";

session_start();
if (!isset($_SESSION['uid'])) {
	$_SESSION['uid'] = 0;
	$_SESSION['lang'] = 'gr';
	$_SESSION["admin"] = 0;
}

//SET AND INCLUDE LANGUAGE FILE
$lang = $_SESSION['lang'];
include("lang/".$lang.".php");

//INCLUDES
include("core/template.php");

class head {
	public $title = _SITETITLE;
	public $js = '';
	
	public function add($string) {
		$this->title.= _TITLESEPERATOR.$string;
	}
	
	public function addjs($string) {
		$this->js.= "\t<script type = \"text/javascript\"  src=\"".$string."\"></script>\n";
	}
}

$header = new head();

If (!($db = mysql_connect($db_info["host"], $db_info["username"], $db_info["password"]))) { echo 'Database connect error'; }
mysql_query ('SET CHARACTER SET utf8');
mysql_query ('SET COLLATION_CONNECTION=utf8_unicode_ci');
if (!(mysql_select_db($db_info["database"], $db))) { echo 'Database select error'; }

//include("core/get_addresses.php");
?>