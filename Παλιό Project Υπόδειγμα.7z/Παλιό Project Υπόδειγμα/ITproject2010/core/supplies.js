function supedit(sid) {
	obj=document.getElementById('sup'+sid);
	obj.innerHTML='<input type="text" id="supv'+sid+'" value="' + obj.innerHTML + '">';
	document.getElementById('supe'+sid).style.display='none';
	document.getElementById('sups'+sid).style.display='';
}

function supsave(sid) {
	supv = document.getElementById('supv'+sid).value;
	if (supv.length) {
		var xmlhttp;
		xmlhttp=new XMLHttpRequest();
		var qstr="value="+supv;
		var url_="api.php?do=editsup&sid="+sid;
		xmlhttp.open("POST",url_,true);
		xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xmlhttp.setRequestHeader('Content-length', qstr.length);
		xmlhttp.onreadystatechange=function() {
			if(xmlhttp.readyState==4){
				if (xmlhttp.responseText == 1) {
					document.getElementById('sup'+sid).innerHTML=supv;
					document.getElementById('sups'+sid).style.display='none';
					document.getElementById('supe'+sid).style.display='';
				}
			}
		};
		xmlhttp.send(qstr);
	}
}

function addsup() {
	supv=document.getElementById('addsupv').value;
	if (supv.length) {
		var xmlhttp;
		xmlhttp=new XMLHttpRequest();
		var qstr="value="+supv;
		var url_="api.php?do=addsup";
		xmlhttp.open("POST",url_,true);
		xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xmlhttp.setRequestHeader('Content-length', qstr.length);
		xmlhttp.onreadystatechange=function() {
			if(xmlhttp.readyState==4){
				sid=xmlhttp.responseText;
				if (sid != 0) {
					list=document.getElementById('sup');
					newsup=document.createElement('li');
					newsup.id='s'+sid;
					newsup.innerHTML='<span id="sup' + sid + '">' + supv + '</span>'
							+ ' <img src = "template/img/save.png" id="sups' + sid + '" onclick="supsave(\'' + sid + '\')" style="display: none; cursor:pointer">'
							+ ' <img src = "template/img/edit.png" id="supe' + sid + '" onclick="supedit(\'' + sid + '\')" style="cursor:pointer">'
							+ ' <img src = "template/img/delete.png" id="supd' + sid + '" onclick="delsup(\'' + sid + '\')" style="cursor:pointer">';
					list.insertBefore(newsup,document.getElementById('addsup'));
					document.getElementById('addsupv').value='';
				}
			}
		};
		xmlhttp.send(qstr);
	}
}

function delsup(sid) {
	var ask=confirm("Do you really want to delete?");
	if (ask==true) {
		var xmlhttp;
		xmlhttp=new XMLHttpRequest();
		var url_="api.php?do=delsup&sid="+sid;
		xmlhttp.open("GET",url_,true);
		xmlhttp.onreadystatechange=function() {
			if(xmlhttp.readyState==4){
				if (xmlhttp.responseText == 1) {
					document.getElementById('sup').removeChild(document.getElementById('s'+sid));
				}
			}
		};
		xmlhttp.send(null);
	}
}