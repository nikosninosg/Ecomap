function initialize() {
	var myLatlng = new google.maps.LatLng(38.250445,21.750046);
	var myOptions = {
      zoom: 14,
      center: myLatlng,
      navigationControl: true,
      mapTypeControl: true,
   		scaleControl: true,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    var map = new google.maps.Map(document.getElementById("map"), myOptions);
    
  var xmlhttp;
	if (window.XMLHttpRequest){
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	} 
	else if (window.ActiveXObject){ // code for IE6, IE5.  
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	else {
		alert("Your browser does not support XMLHTTP!");
	} 
	var qstr="?do=mark";
	var url_="api.php"+qstr;
	xmlhttp.open("GET",url_,true);
	xmlhttp.onreadystatechange=function() { rstatech(xmlhttp, map) };
	xmlhttp.send(null);
    
    
}

function rstatech(Xobj,map1){
	if(Xobj.readyState==4){
		var micon_recent = new google.maps.MarkerImage("/template/img/recent.png");
    var micon_popular = new google.maps.MarkerImage("/template/img/popular.png");
    var markerlist = Xobj.responseXML.getElementsByTagName("marker");
		for(i=0; i<markerlist.length; i++){
	    var marker = new google.maps.Marker({
	        position: new google.maps.LatLng(markerlist.item(i).getAttribute("lat"),markerlist.item(i).getAttribute("lng")), 
	        map: map1,
	        icon: (markerlist.item(i).getAttribute("type")=="recent")?micon_recent:micon_popular,
	        title: markerlist.item(i).getAttribute("address")
	    });
  	}
	}
}

window.onload = initialize;