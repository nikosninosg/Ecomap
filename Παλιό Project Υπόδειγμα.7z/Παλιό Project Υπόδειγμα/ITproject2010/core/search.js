function search(page){
	page = typeof(page) != 'string' ? '1' : page;
	var xmlhttp;
	var obj=document.searchads;
	if (window.XMLHttpRequest){
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	} 
	else if (window.ActiveXObject){ // code for IE6, IE5.  
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	else {
		alert("Your browser does not support XMLHTTP!");
	}
	var qstr="page="+page+"&";
	for (i=0; i<obj.getElementsByTagName("input").length; i++) {
        if (obj.getElementsByTagName("input")[i].type == "text") {
           qstr += obj.getElementsByTagName("input")[i].name + "=" + 
                   obj.getElementsByTagName("input")[i].value + "&";
        }
        if (obj.getElementsByTagName("input")[i].type == "checkbox") {
           if (obj.getElementsByTagName("input")[i].checked) {
              qstr += obj.getElementsByTagName("input")[i].name + "=" + 
                   obj.getElementsByTagName("input")[i].value + "&";
           //} else {
           //   qstr += obj.getElementsByTagName("input")[i].name + "=&";
           }
        }
        if (obj.getElementsByTagName("input")[i].type == "radio") {
           if (obj.getElementsByTagName("input")[i].checked) {
              qstr += obj.getElementsByTagName("input")[i].name + "=" + 
                   obj.getElementsByTagName("input")[i].value + "&";
           }
     }  
     if (obj.getElementsByTagName("input")[i].tagName == "SELECT") {
        var sel = obj.getElementsByTagName("input")[i];
        qstr += sel.name + "=" + sel.options[sel.selectedIndex].value + "&";
     }
   }
	var url_="api.php?do=search";
	xmlhttp.open("POST",url_,true);
	xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xmlhttp.setRequestHeader('Content-length', qstr.length);
	xmlhttp.onreadystatechange=function() { searchready(xmlhttp) };
	xmlhttp.send(qstr);

}
function searchready(Xobj){
	if(Xobj.readyState==4){
		var _suggel = document.getElementById("results");
		_suggel.innerHTML=Xobj.responseText;
	}
}

window.onload = search;