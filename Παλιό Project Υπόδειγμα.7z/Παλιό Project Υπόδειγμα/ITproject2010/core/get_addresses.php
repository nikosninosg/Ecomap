<?php
$start[0]=38.290206;
$start[1]=21.707268;
$end[0]=38.204195;
$end[1]=21.792412;

$area[]= array(38.293604,21.754594,38.282219,21.798624);
$area[]= array(38.281107,21.734831,38.250714,21.785728);
$area[]= array(38.244243,21.714103,38.211003,21.781930);
//$area[]= array(,,,);

for($k=0;$k<1;$k++) {
unset($fetsh,$address,$num,$nums,$tk);
$addressop = mysql_fetch_array(mysql_query('SELECT * FROM conf WHERE opt=2'));
$power=$addressop['par1'];
$step[0]=$addressop['par2'];
$step[1]=$addressop['par3'];
//$power=1;
//$step[0]=0;
//$step[1]=0;
while(!isset($fetsh)) {
	$chekpoint[0]=$start[0]-($start[0]-$end[0])/pow(2,$power) - ($start[0]-$end[0])/pow(2,$power-1)*$step[0];
	$chekpoint[1]=$start[1]+($end[1]-$start[1])/pow(2,$power) + ($end[1]-$start[1])/pow(2,$power-1)*$step[1];
	
	if ($chekpoint[0] < $end[0]) {
		$step[0]=0;
		$step[1]++;
	}
	elseif ($chekpoint[1] > $end[1]) {
		$power++;
		$step[0]=0;
		$step[1]=0;
	}
	else {
		$step[0]++;
		foreach ($area AS $parea) {
			//print_r($parea);
			if ($parea[0] > $chekpoint[0] AND $chekpoint[0] > $parea[2] AND $parea[1] < $chekpoint[1] AND $chekpoint[1] < $parea[3]) {
				$fetsh=round($chekpoint[0],6).','.round($chekpoint[1],6);
				break;
			}
			//$fetsh=round($chekpoint[0],6).','.round($chekpoint[1],6);
		}
	}
}
//$fetsh="38.256953,21.742158";

//$fetsh="http://maps.google.com/maps/api/geocode/json?language=el&region=GR&sensor=false&latlng=".$fetsh;
//echo $fetsh;
$json = json_decode(file_get_contents("http://maps.google.com/maps/api/geocode/json?language=el&region=GR&sensor=false&latlng=".$fetsh));
//echo $json->status.'<br>';
//echo $jsonen->status.'<br>';
$succsessfull = false;
if ((strcasecmp($json->status,'ok')==0 OR strcasecmp($json->status,'ZERO_RESULTS')==0)) {
	$succsessfull = true;
 //echo round(100*(pow(2,$power-1)*$step[1]+$step[0])/(pow(2,$power-1)*pow(2,$power-1)),3)."% - ".round(100*$step[0]/pow(2,$power-1),2)."%<br>";
//var_dump($json);
//var_dump($jsonen);
foreach($json->results as $value){
	foreach ($value->address_components as $comp) {
		if ($comp->types[0]=='route') {
			$address = $comp->long_name;
		}
		elseif ($comp->types[0]=='postal_code') {
			$tk = $comp->long_name;
		}
		elseif ($comp->types[0]=='street_number') {
			$num = $comp->long_name;
		}
		elseif ($comp->types[0]=='sublocality') {
			$patra = (strcasecmp($comp->long_name,'Πάτρα')==0)? 1:0;
		}
	}
	break;
}

if (isset($address)) {
	if ($patra) {
		//$tk = isset($tk) ? '"'.$tk.'"' : 'NULL';
		if (!isset($num))  $num = 0;
		$nums = explode("-", $num);
		$num1 = $nums[0];
		$num2 = (isset($nums[1])) ? $nums[1] : $num1 ;
		$res = mysql_query('SELECT * FROM address WHERE street_el LIKE "'.$address.'" AND tk '.(isset($tk) ? '= '.$tk : 'IS NULL'));
		if (mysql_num_rows($res)) {
			if ($num != 0) {
				$sqlstreet = mysql_fetch_array($res);
				if ($num1 > $sqlstreet['minnum'] AND $sqlstreet['minnum']!=0) {
					$num1 = $sqlstreet['minnum'];
				}
				if ($num2 < $sqlstreet['maxnum'] AND $sqlstreet['maxnum']!=0) {
					$num2 = $sqlstreet['maxnum'];
				}
				$q = 'UPDATE address SET minnum='.$num1.', maxnum='.$num2.' WHERE street_el LIKE "'.$address.'" AND tk '.(isset($tk) ? '= '.$tk : 'IS NULL');
				//echo $q.'<br>';
				mysql_query($q);
			}
		}
		else {
			$jsonen = json_decode(file_get_contents("http://maps.google.com/maps/api/geocode/json?language=en&region=GR&sensor=false&latlng=".$fetsh));
			if (strcasecmp($jsonen->status,'ok')==0 OR strcasecmp($jsonen->status,'ZERO_RESULTS')==0) {
				foreach($jsonen->results as $value){
					foreach ($value->address_components as $comp) {
						if ($comp->types[0]=='route') {
							$addressen = $comp->long_name;
						}
					}
					break;
				}
				$q='INSERT INTO address (tk,street,street_el,minnum,maxnum) VALUES ('.(isset($tk) ? $tk : 'NULL').',"'.$addressen.'","'.$address.'",'.$num1.','.$num2.')';
				//echo $q.'<br>';
				mysql_query($q);
			}
			else {
				$succsessfull = false;
			}
		}
	}
}
if ($succsessfull) {
	mysql_query('UPDATE conf SET par1='.$power.', par2='.$step[0].', par3='.$step[1].' WHERE opt=2');
}
//echo "$patra $addressen $address $tk $num";
} else echo $json->status.'<br>';
}
?>