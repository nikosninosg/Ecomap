function edituser() {
	document.getElementById('userinfo').style.display='none';
	document.getElementById('edituser').style.display='';
}

function saveuser(uid) {
	var obj=document.register;
	if (validate()) {
		var xmlhttp;
		xmlhttp=new XMLHttpRequest();
		var qstr="uid="+uid+"&";
		for (i=0; i<obj.getElementsByTagName("input").length; i++) {
    	if (obj.getElementsByTagName("input")[i].type == "text") {
    		qstr += obj.getElementsByTagName("input")[i].name + "=" + 
        				obj.getElementsByTagName("input")[i].value + "&";
    	}
      if (obj.getElementsByTagName("input")[i].type == "password") {
    		qstr += obj.getElementsByTagName("input")[i].name + "=" + 
        				obj.getElementsByTagName("input")[i].value + "&";
    	}
		}
		var url_="api.php?do=edituser";
		xmlhttp.open("POST",url_,true);
		xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xmlhttp.setRequestHeader('Content-length', qstr.length);
		xmlhttp.onreadystatechange=function() {
			if(xmlhttp.readyState==4){
				//alert(xmlhttp.responseText);
				if (xmlhttp.responseText == 1 || xmlhttp.responseText == 2) {
					if (xmlhttp.responseText == 2) {
						alert('O Kodikos den alakse');
					}
					document.getElementById('uifirstname').innerHTML=obj.firstname.value;
					document.getElementById('uifn').style.display= (obj.firstname.value=='') ? 'none' : '';
					
					document.getElementById('uilastname').innerHTML=obj.lastname.value;
					document.getElementById('uiln').style.display= (obj.lastname.value=='') ? 'none' : '';
					
					document.getElementById('uiemail').innerHTML=obj.email.value;
					
					document.getElementById('uihomenumber').innerHTML=obj.homenumber.value;
					document.getElementById('uihn').style.display= (obj.homenumber.value=='') ? 'none' : '';
					
					document.getElementById('uimobilephone').innerHTML=obj.mobilephone.value;
					document.getElementById('uimp').style.display= (obj.mobilephone.value=='') ? 'none' : '';
					
					document.getElementById('uifax').innerHTML=obj.fax.value;
					document.getElementById('uif').style.display= (obj.fax.value=='') ? 'none' : '';
					
					document.getElementById('uiworknumber').innerHTML=obj.worknumber.value;
					document.getElementById('uiwn').style.display= (obj.worknumber.value=='') ? 'none' : '';
					
					document.getElementById('edituser').style.display='none';
					document.getElementById('userinfo').style.display='';
					
					obj.oldpassword.value='';
					obj.password.value='';
					obj.passwordv.value='';
				}
			}
		};
		xmlhttp.send(qstr);
	}
}

function canceluser() {
	document.getElementById('edituser').style.display='none';
	document.getElementById('userinfo').style.display='';
}