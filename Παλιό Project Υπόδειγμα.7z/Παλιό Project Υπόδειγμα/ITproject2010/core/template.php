<?php

class template {
	
    public $tempfile;
    public $vars = array();
    
    function load($nvars) {
    	$this->vars = array_merge_recursive($this->vars,$nvars);
    }
    
    function draw($temp) {
        $this->tempfile = $temp;
        //print_r($this->vars);
        $content = file_get_contents('template/'.$this->tempfile);
        $preg = array(
        	'/{(\w+)}/',
        	'/<!- IF (\w+) -->/',
        	'/<!- ELSEIF (\w+) -->/',
        	'/<!- ELSE -->/',
        	'/<!- ENDIF -->/',
        	'/<!- BEGIN (\w+) -->/',
        	'/{(\w+).(\w+)}/',
        	'/<!- IF (\w+).(\w+) -->/',
        	'/<!- ELSEIF (\w+).(\w+) -->/',
        	'/<!- BEGIN (\w+).(\w+) -->/',
        	'/{(\w+).(\w+).(\w+)}/',
        	'/<!- FINISH -->/'
        );
        $replace = array(
        	'<?php echo $this->vars[\'\1\']; ?>',
        	'<?php if ($this->vars[\'\1\']) { ?>',
        	'<?php } elseif ($this->vars[\'\1\']) { ?>',
        	'<?php } else { ?>',
        	'<?php } ?>',
        	'<?php if (isset($this->vars[\'\1\'])) { for($i[\'\1\']=0;$i[\'\1\']<count($this->vars[\'\1\']);$i[\'\1\']++) { ?>',
        	'<?php echo $this->vars[\'\1\'][$i[\'\1\']][\'\2\']; ?>',
        	'<?php if ($this->vars[\'\1\'][$i[\'\1\']][\'\2\']) { ?>',
        	'<?php } elseif ($this->vars[\'\1\'][$i[\'\1\']][\'\2\']) { ?>',
        	'<?php if (isset($this->vars[\'\1\'][$i[\'\1\']][\'\2\'])) { for($j[\'\2\']=0;$j[\'\2\']<count($this->vars[\'\1\'][$i[\'\1\']][\'\2\']);$j[\'\2\']++) { ?>',
        	'<?php echo $this->vars[\'\1\'][$i[\'\1\']][\'\2\'][$j[\'\2\']][\'\3\']; ?>',
        	'<?php }} ?>'
        );
        $content = preg_replace($preg,$replace,$content);
        //echo htmlspecialchars($content);
        file_put_contents('cache/'.$this->tempfile.'.inc',$content);
        include('cache/'.$this->tempfile.'.inc');
    }

}
?>