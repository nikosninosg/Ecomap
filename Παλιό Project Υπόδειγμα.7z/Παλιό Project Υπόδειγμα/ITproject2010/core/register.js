function validate() {
	x=document.register;
	pass=x.password.value;
	passv=x.passwordv.value;
	
	if (check_username(x.username)&&check_password(x)
								&&check_passwordv(x)
								&&check_email(x.email.value)
								&&check_telnumbers(x))
		return true;
	
	return false;
}

function check_username(x){
	if (x && x.value.length<4) {
		document.getElementById('invalid_usern').style.visibility = 'visible';
		return false;
	}else{
		document.getElementById('invalid_usern').style.visibility = 'hidden';
		return true;
	}
}

function check_password(x){
	if (!(x.oldpassword) || (x.oldpassword && x.oldpassword.value.length > 0)) {
		if (x.password.value.length<6){
			document.getElementById('invalid_pass').style.visibility = 'visible';
			return false;
		}else{
			document.getElementById('invalid_pass').style.visibility = 'hidden';
			return true;
		}
	}
	document.getElementById('invalid_pass').style.visibility = 'hidden';
	return true;
}

function check_passwordv(x){
	if (x.passwordv.value!=x.password.value){
		document.getElementById('invalid_passv').style.visibility = 'visible';
		return false;
	}else{
		document.getElementById('invalid_passv').style.visibility = 'hidden';
		return true;
	}
}

function check_telnumbers(x){
	if (x.homenumber.value.length==10 && !isNaN(x.homenumber.value)|| x.mobilephone.value.length==10 && !isNaN(x.mobilephone.value)
																   || x.fax.value.length==10 && !isNaN(x.fax.value)
																   || x.worknumber.value.length==10 && !isNaN(x.worknumber.value)) {
		document.getElementById('tel_number').style.visibility = 'hidden';
		return true;
	}else{
		document.getElementById('tel_number').style.visibility = 'visible';
		return false;
	}
}

function check_email(x){
	var at="@"
	var dot="."
	var lat=x.indexOf(at)
	var lstr=x.length
	var ldot=x.indexOf(dot)
	if (x.indexOf(at)==-1){
	   document.getElementById('invalid_email').style.visibility = 'visible';
	   return false
	}
	if (x.indexOf(at)==-1 || x.indexOf(at)==0 || x.indexOf(at)==lstr){
	   document.getElementById('invalid_email').style.visibility = 'visible';
	   return false
	}
	if (x.indexOf(dot)==-1 || x.indexOf(dot)==0 || x.indexOf(dot)==lstr){
		document.getElementById('invalid_email').style.visibility = 'visible';
		return false
	}
	if (x.indexOf(at,(lat+1))!=-1){
		document.getElementById('invalid_email').style.visibility = 'visible';
		return false
	}
	if (x.substring(lat-1,lat)==dot || x.substring(lat+1,lat+2)==dot){
		document.getElementById('invalid_email').style.visibility = 'visible';
		return false
	}
	if (x.indexOf(dot,(lat+2))==-1){
		document.getElementById('invalid_email').style.visibility = 'visible';
		return false
	}
	if (x.indexOf(" ")!=-1){
		document.getElementById('invalid_email').style.visibility = 'visible';
		return false
	}
	document.getElementById('invalid_email').style.visibility = 'hidden';
	return true	
}