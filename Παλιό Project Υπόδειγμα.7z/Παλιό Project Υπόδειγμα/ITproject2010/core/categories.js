function catedit(cid) {
	obj=document.getElementById('cat'+cid);
	obj.innerHTML='<input type="text" id="catv'+cid+'" value="' + obj.innerHTML + '">';
	document.getElementById('cate'+cid).style.display='none';
	document.getElementById('cats'+cid).style.display='';
}

function catsave(cid) {
	catv = document.getElementById('catv'+cid).value;
	if (catv.length) {
		var xmlhttp;
		xmlhttp=new XMLHttpRequest();
		var qstr="value="+catv;
		var url_="api.php?do=editcat&cid="+cid;
		xmlhttp.open("POST",url_,true);
		xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xmlhttp.setRequestHeader('Content-length', qstr.length);
		xmlhttp.onreadystatechange=function() {
			if(xmlhttp.readyState==4){
				if (xmlhttp.responseText == 1) {
					document.getElementById('cat'+cid).innerHTML=catv;
					document.getElementById('cats'+cid).style.display='none';
					document.getElementById('cate'+cid).style.display='';
				}
			}
		};
		xmlhttp.send(qstr);
	}
}

function addcat() {
	catv=document.getElementById('addcatv').value;
	if (catv.length) {
		var xmlhttp;
		xmlhttp=new XMLHttpRequest();
		var qstr="value="+catv;
		var url_="api.php?do=addcat";
		xmlhttp.open("POST",url_,true);
		xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xmlhttp.setRequestHeader('Content-length', qstr.length);
		xmlhttp.onreadystatechange=function() {
			if(xmlhttp.readyState==4){
				cid=xmlhttp.responseText;
				if (cid != 0) {
					list=document.getElementById('cat');
					newcat=document.createElement('li');
					newcat.id='c'+cid;
					newcat.innerHTML='<span id="cat' + cid + '">' + catv + '</span>'
							+ ' <img src = "template/img/save.png" id="cats' + cid + '" onclick="catsave(\'' + cid + '\')" style="display: none; cursor:pointer">'
							+ ' <img src = "template/img/edit.png" id="cate' + cid + '" onclick="catedit(\'' + cid + '\')" style="cursor:pointer">'
							+ ' <img src = "template/img/delete.png" id="catd' + cid + '" onclick="delcat(\'' + cid + '\')" style="cursor:pointer">';
					list.insertBefore(newcat,document.getElementById('addcat'));
					document.getElementById('addcatv').value='';
				}
			}
		};
		xmlhttp.send(qstr);
	}
}

function delcat(cid) {
	var ask=confirm("Do you really want to delete?");
	if (ask==true) {
		var xmlhttp;
		xmlhttp=new XMLHttpRequest();
		var url_="api.php?do=delcat&cid="+cid;
		xmlhttp.open("GET",url_,true);
		xmlhttp.onreadystatechange=function() {
			if(xmlhttp.readyState==4){
				if (xmlhttp.responseText == 1) {
					document.getElementById('cat').removeChild(document.getElementById('c'+cid));
				}
			}
		};
		xmlhttp.send(null);
	}
}