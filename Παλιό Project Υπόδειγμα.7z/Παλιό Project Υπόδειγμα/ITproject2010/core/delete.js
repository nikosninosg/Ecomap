function  deletead(aid,obj){
	var xmlhttp;
	if (window.XMLHttpRequest){
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	} 
	else if (window.ActiveXObject){ // code for IE6, IE5.  
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	else {
		alert("Your browser does not support XMLHTTP!");
	}
	var ask=confirm("Do you really want to delete?");
	if (ask==true) {
		var qstr="?do=deletead&ad="+aid;
		var url_="api.php"+qstr;
		xmlhttp.open("GET",url_,true);
		xmlhttp.onreadystatechange=function() { deletea(xmlhttp,obj) };
		xmlhttp.send(null);
	}
}
function deletea(Xobj,ob){
	if(Xobj.readyState==4){
		if (Xobj.responseText==1) {
			ob.style.display = 'none';
		}
		else {
			alert("ERROR delete");
		} 
	}
}