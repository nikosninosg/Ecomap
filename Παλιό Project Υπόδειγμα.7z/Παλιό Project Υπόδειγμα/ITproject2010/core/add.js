function validate() {
	x=document.ads;
	
	submitOK="True";
	if (x.cost.value.length==0) {
	 alert("Prosthese Kostos");
	 submitOK="False";
	}
	if (x.area.value.length==0) {
	 alert("Prosthese Tetragonika");
	 submitOK="False";
	}
	if (!x.sell_rent[0].checked && !x.sell_rent[1].checked) {
	 alert("Epelekse Polisi i pros enikiasi");
	 submitOK="False";
	}
	if (x.address.value.length==0) {
		alert("Simplirose Diefthinsi");
		submitOK="False";
	}
	if (x.address_num.value.length==0) {
		alert("Simplirose Arithmo Diefthinsi");
		submitOK="False";
	}
	if (x.lat.value.length==0 || x.lng.value.length==0) {
		alert("Epelekse simio sto xarti");
		submitOK="False";
	}
	if (submitOK=="False") {
	 return false;
	}
	else {
		return true;
	}
}

function show(id) {
	document.getElementById(id).style.display = ''; 
	document.getElementById(id+'a').style.display = 'none'; 
}

function ajaxcall(par){
	var xmlhttp;
	if (window.XMLHttpRequest){
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	} 
	else if (window.ActiveXObject){ // code for IE6, IE5.  
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	else {
		alert("Your browser does not support XMLHTTP!");
	} 
	var qstr="?do=ads&address="+par.value;
	var url_="api.php"+qstr;
	xmlhttp.open("GET",url_,true);
	xmlhttp.onreadystatechange=function() { rstatech(xmlhttp, par) };
	xmlhttp.send(null);

}
function rstatech(Xobj,par1){
	if(Xobj.readyState==4){
		var _suggel = document.getElementById("suggestionel");
		_suggel.style.top = par1.offsetTop + 20 + "px"; 
		_suggel.style.left = par1.offsetLeft + "px";
		_suggel.innerHTML=Xobj.responseText;
		_suggel.style.display='block';
	}
}
var geocoder;
var map;
var marker;
var edit;
function initialize() {
	geocoder = new google.maps.Geocoder();
	if (document.ads.lat.value.length==0 || document.ads.lng.value.length==0) {
		var myLatlng = new google.maps.LatLng(38.250445,21.730046);
		edit=true;
	}
	else {
		var myLatlng = new google.maps.LatLng(parseFloat(document.ads.lat.value),parseFloat(document.ads.lng.value));
		edit=false;
	}
	var myOptions = {
      zoom: (edit)?15:16,
      center: myLatlng,
      navigationControl: true,
      mapTypeControl: true,
   		scaleControl: true,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    map = new google.maps.Map(document.getElementById("map"), myOptions);
    
	marker = new google.maps.Marker({
	        position: myLatlng, 
	        map: map,
	        draggable: edit,
	        visible: !(edit)
	    });
    
    google.maps.event.addListener(marker, 'dragend', function() {
    	var mLatlng = marker.getPosition();
    	document.ads.lat.value =mLatlng.lat();
	    document.ads.lng.value =mLatlng.lng();
	    codeLatLng();
	  });
	  
		google.maps.event.addListener(map, 'click', function(event) {
				if (edit) {
			    var mLatlng = event.latLng;
			    marker.setPosition(mLatlng);
			    marker.setVisible(true);
		    	document.ads.lat.value =mLatlng.lat();
			    document.ads.lng.value =mLatlng.lng();
			    codeLatLng();
			  }
		  });
}
function codeLatLng() {
    var lat = parseFloat(document.ads.lat.value);
    var lng = parseFloat(document.ads.lng.value);
    var latlng = new google.maps.LatLng(lat, lng);
    geocoder.geocode({'latLng': latlng, 'language': 'el'}, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
        if (results[0]) {
        	for(i=0; i<results[0].address_components.length; i++){
        		if (results[0].address_components[i].types[0]=='route') {
          		document.ads.address.value=results[0].address_components[i].long_name;
          	}
          	else if (results[0].address_components[i].types[0]=='street_number') {
          		document.ads.address_num.value=results[0].address_components[i].long_name;
          	}
          	else if (results[0].address_components[i].types[0]=='postal_code') {
          		document.ads.pc.value=results[0].address_components[i].long_name;
          	}
        	}
        }
      } else {
        alert("Geocoder failed due to: " + status);
      }
    });
}

function editad() {
	document.getElementById('ainfo').style.display='none';
	document.getElementById('editad').style.display='';
	marker.setDraggable(true);
	edit=true;
}

function cancelad(lat,lng) {
	document.getElementById('editad').style.display='none';
	document.getElementById('ainfo').style.display='';
	document.ads.lat.value =lat;
	document.ads.lng.value =lng;
	var cLatlng = new google.maps.LatLng(parseFloat(document.ads.lat.value),parseFloat(document.ads.lng.value));
	marker.setPosition(cLatlng);
	marker.setDraggable(false);
	edit=false;
}

function savead(aid) {
	var obj=document.ads;
	if (validate()) {
		var xmlhttp;
		xmlhttp=new XMLHttpRequest();
		var qstr="aid="+aid+"&";
		for (i=0; i<obj.getElementsByTagName("input").length; i++) {
    	if (obj.getElementsByTagName("input")[i].type == "text") {
           qstr += obj.getElementsByTagName("input")[i].name + "=" + 
                   obj.getElementsByTagName("input")[i].value + "&";
    	}
    	if (obj.getElementsByTagName("input")[i].type == "hidden") {
           qstr += obj.getElementsByTagName("input")[i].name + "=" + 
                   obj.getElementsByTagName("input")[i].value + "&";
    	}
    	if (obj.getElementsByTagName("input")[i].type == "checkbox") {
   			if (obj.getElementsByTagName("input")[i].checked) {
              qstr += obj.getElementsByTagName("input")[i].name + "=" + 
                   obj.getElementsByTagName("input")[i].value + "&";
           //} else {
           //   qstr += obj.getElementsByTagName("input")[i].name + "=&";
    		}
    	}
    	if (obj.getElementsByTagName("input")[i].type == "radio") {
    			if (obj.getElementsByTagName("input")[i].checked) {
              qstr += obj.getElementsByTagName("input")[i].name + "=" + 
                   obj.getElementsByTagName("input")[i].value + "&";
    		}
	  	}
	  }
	  for (i=0; i<obj.getElementsByTagName("select").length; i++) {
	  		var sel = obj.getElementsByTagName("select")[i];
	  		qstr += sel.name + "=" + sel.options[sel.selectedIndex].value + "&";
  	}
  	var url_="api.php?do=editad";
		xmlhttp.open("POST",url_,true);
		xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xmlhttp.setRequestHeader('Content-length', qstr.length);
		xmlhttp.onreadystatechange=function() {
			if(xmlhttp.readyState==4){
				//alert(xmlhttp.responseText);
				if (xmlhttp.responseText == 1) {
					document.getElementById('aicat').innerHTML=obj.category.options[obj.category.selectedIndex].text;
					document.getElementById('aiaddress').innerHTML=obj.address.value;
					document.getElementById('ainum').innerHTML=obj.address_num.value;
					document.getElementById('aicost').innerHTML=obj.cost.value;
					document.getElementById('aiarea').innerHTML=obj.area.value;
					
					document.getElementById('aipc').innerHTML=obj.pc.value;
					document.getElementById('apc').style.display= (obj.pc.value=='') ? 'none' : '';
					
					document.getElementById('aiyear').innerHTML=obj.since.value;
					document.getElementById('ay').style.display= (obj.since.value=='') ? 'none' : '';
					
					for (i=0; i<obj.getElementsByTagName("input").length; i++) {
			    	if (obj.getElementsByTagName("input")[i].type == "checkbox") {
			   			if (obj.getElementsByTagName("input")[i].checked) {
			        	document.getElementById('s'+obj.getElementsByTagName("input")[i].value).style.display='';
			    		}
			    		else {
			    			document.getElementById('s'+obj.getElementsByTagName("input")[i].value).style.display='none';
			    		}
			    	}
			    	if (obj.getElementsByTagName("input")[i].type == "radio") {
			    			if (obj.getElementsByTagName("input")[i].checked) {
			    				if (obj.getElementsByTagName("input")[i].value==1) {
			    					document.getElementById('aisr').innerHTML=document.getElementById('sell').innerHTML;
			    				}
			    				else {
			    					document.getElementById('aisr').innerHTML=document.getElementById('rent').innerHTML;
			    				}
			    		}
				  	}
				  }
				  
					marker.setDraggable(false);
					edit=false;
					document.getElementById('editad').style.display='none';
					document.getElementById('ainfo').style.display='';
				}
			}
		};
		xmlhttp.send(qstr);
	}
}

window.onload = initialize;