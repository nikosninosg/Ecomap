function  favorite(par,obj){
	var xmlhttp;
	if (window.XMLHttpRequest){
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	} 
	else if (window.ActiveXObject){ // code for IE6, IE5.  
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	else {
		alert("Your browser does not support XMLHTTP!");
	} 
	var qstr="?do=fav&ad="+par;
	var url_="api.php"+qstr;
	xmlhttp.open("GET",url_,true);
	xmlhttp.onreadystatechange=function() { favstatech(xmlhttp,obj) };
	xmlhttp.send(null);

}
function favstatech(Xobj,ob){
	if(Xobj.readyState==4){
		if (Xobj.responseText==1) {
			ob.innerHTML='<img src = "template/img/favourite.png">';
		}
		else if (Xobj.responseText==0) {
			ob.innerHTML='<img src = "template/img/unfavourite.png">';
		}
		else {
			alert("ERROR favorites");
		} 
	}
}