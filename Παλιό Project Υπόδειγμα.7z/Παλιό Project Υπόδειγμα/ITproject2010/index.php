<?php
//user/

include("core/system.php");
if (isset($_GET['goto'])) {
	include($_GET['goto'].(isset($_GET['do'])?"-".$_GET['do']:"").".php");
}
else {
	$header->add(_HOMEPAGE);
	$header->addjs("http://maps.google.com/maps/api/js?sensor=false&language=el");
	$header->addjs("core/markers.js");
	include("header.php");
	
	$hometemp = new template();
	$hometemp->load(array(
						  	"VIEW" => _VIEW,
						  	"RECENT" => _RECENT,
						  	"POPULAR" => _POPULAR
						  	
						  ));
	//RECENT
	$result = mysql_query('SELECT * FROM ads,users,categories WHERE ads.uid=users.uid AND ads.category=categories.cid  AND ads.approved=1 ORDER BY aid  DESC LIMIT 5');
	while($ad = mysql_fetch_array($result)) {
		$hometemp->load(array("RADS" => array(array(
																				"ADDRESS" => $ad['address'],
					 															"NUM" => $ad['address_num'],
					 															"COST" => $ad['cost'],
					 															"VLINK" => '?goto=ads&amp;oj='.$ad['aid']
					 													))
  							));
  }
  //POPULAR
  $result = mysql_query('SELECT * FROM ads,users,categories WHERE ads.uid=users.uid AND ads.category=categories.cid  AND ads.approved=1 ORDER BY views  DESC, aid ASC LIMIT 5');
	while($ad = mysql_fetch_array($result)) {
		$hometemp->load(array("PADS" => array(array(
																				"ADDRESS" => $ad['address'],
					 															"NUM" => $ad['address_num'],
					 															"COST" => $ad['cost'],
					 															"VLINK" => '?goto=ads&amp;oj='.$ad['aid']
					 													))
  							));
  }
  
  $hometemp->draw('home.html');
}

mysql_close($db);

if (defined('HEADER')) { include("footer.php"); }
?>