<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Initialize</title>
</head>
<body>
<?php
//evala html header pou pano gia na dixnei sosta ta unicode :P
	include("core/system.php");
	mysql_query("INSERT INTO `users` (`username`, `firstname`, `lastname`, `email`, `homenumber`, `mobilephone`, `fax`, `worknumber`, `password`, `admin`) VALUES ('admin', NULL, NULL, 'a@a.a', NULL, '123', NULL, NULL, '21232f297a57a5a743894a0e4a801fc3', 1)");
	for($i=0;$i<1000;$i++){
		$result = mysql_query('INSERT into users (username,firstname,lastname,email,homenumber,mobilephone,fax,worknumber,password) VALUES ("user'.$i.'",NULL,NULL,"a@b.gr","1234567899",NULL,NULL,NULL,MD5("user'.$i.'"))');
		if ($result) {
			echo 'Επιτυχία εγγραφής χρήστη user'.$i.'<br>';
		}
		else {
			echo 'Αποτυχία εγγραφής χρήστη user'.$i.'<br>';
		}
	}

	for($i=0;$i<1000;$i++){
		$result1=mysql_query('SELECT uid FROM users WHERE username="user'.$i.'"');
		//var_dump($result);
		$uid = mysql_result($result1,0);
		//mian panalipsi gia na valoume  kamposes aggelies gia ton kathe xristi! episeis ekama tis nan apefthias approve
		//tzai edokimasa tin kathisterisi sto search! arkei polla!!!!!!!!!!! dokimasto tzai esi!
		$max=mt_rand(5,30);
		//echo $max;
		for($j=0;$j<$max;$j++){
			$result2 = mysql_query('INSERT into ads (uid,category,cost,area,since,supplies,sell_rent,pc,address,address_num,lat,lng,views,approved) VALUES ('.$uid.','.mt_rand(1,7).','.(mt_rand(3,50)*50).','.mt_rand(20,80).','.mt_rand(1980,2010).',"|'.mt_rand(1,3).'|",'.mt_rand(1,2).',NULL,"Κανακαρη",'.mt_rand(1,250).',38.247833,21.739058,0,1)');
			if ($result2) {
				echo 'Επιτυχία καταχώρησης αγγελίας για τον χρήστη user'.$i.'<br>';
			}
			else {
				echo 'Αποτυχία καταχώρησης αγγελίας για τον χρήστη user'.$i.'<br>';
			}
		}
	}
	
	mysql_close($db);
?>
</body>
</html>