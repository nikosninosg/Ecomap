<?php
//user/register
$header->add(_REGISTER);
$header->addjs('core/register.js');

include("header.php");

if (!isset($_SESSION["username"])){
	if (isset($_POST["username"])) {
		$result = mysql_query('INSERT into users (username,firstname,lastname,email,homenumber,mobilephone,fax,worknumber,password) VALUES ("'.$_POST['username'].'",'.(($_POST['firstname']=='')?'NULL':'"'.$_POST['firstname'].'"').','.(($_POST['lastname']=='')?'NULL':'"'.$_POST['lastname'].'"').',"'.$_POST['email'].'",'.(($_POST['homenumber']=='')?'NULL':'"'.$_POST['homenumber'].'"').','.(($_POST['mobilephone']=='')?'NULL':'"'.$_POST['mobilephone'].'"').','.(($_POST['fax']=='')?'NULL':'"'.$_POST['fax'].'"').','.(($_POST['worknumber']=='')?'NULL':'"'.$_POST['worknumber'].'"').',MD5("'.$_POST['password'].'"))');
		if ($result) {
			echo 'Επιτυχία εγγραφής!<br><a href=?goto=user>Πατήστε εδώ</a> για να συνδεθείτε.';
		}
		else {
			echo 'Ο χρήστης υπάρχει ήδη<br>';
		}
	}
	if (!isset($result) OR !($result)) {
		echo '<form name="register" method="post" action="" onsubmit="return validate()">';
		echo '<div id="invalid_usern" class="warnings"> Περιορισμός: 4 ψηφία τουλάχιστον </div>';
		echo 'Όνομα Χρήστη*:  <input type="text" name="username" style="position:absolute;left:170px" onBlur="check_username(this)"><br><br>';
		echo '<div id="invalid_pass" class="warnings">Περιορισμός: 6 ψηφία τουλάχιστον</div>';
		echo 'Κωδικός Χρήστη*: <input type="password" name="password" style="position:absolute;left:170px" onBlur="check_password(document.register)"><br><br>';
		echo '<div id="invalid_passv" class="warnings">Αποτυχία επιβεβαίωσης κωδικού</div>';
		echo 'Επιβεβαίωση Κωδικού*: <input type="password" name="passwordv" style="position:absolute;left:170px" onBlur="check_passwordv(document.register)"><br><br>';
		echo 'Όνομα: <input type="text" name="firstname" style="position:absolute;left:170px"><br><br>';
		echo 'Επίθετο: <input type="text" name="lastname" style="position:absolute;left:170px"><br><br>';
		echo '<div id="invalid_email" class="warnings">Δώστε ένα έγκυρο email</div>';
		echo 'E-mail*: <input type="text" name="email" style="position:absolute;left:170px" onBlur="check_email(this.value)"><br><br>';
		echo '<div id="tel_number" class="warnings">Δώστε τουλάχιστον ένα 10ψήφιο τηλέφωνο επικοινωνίας</div>';
		echo 'Σταθερό**: <input type="text" name="homenumber" style="position:absolute;left:170px" onBlur="check_telnumbers(document.register)"><br><br>';
		echo 'Κινητό**: <input type="text" name="mobilephone" style="position:absolute;left:170px" onBlur="check_telnumbers(document.register)"><br><br>';
		echo 'ΦΑΞ**: <input type="text" name="fax" style="position:absolute;left:170px" onBlur="check_telnumbers(document.register)"><br><br>';
		echo 'Εργασίας**: <input type="text" name="worknumber" style="position:absolute;left:170px" onBlur="check_telnumbers(document.register)"><br>';
		echo '<input type="submit" value="Εγγραφή">';
		echo '</form>';
		echo '*Υποχρεωτικά πεδία<br>';
		echo '**Τουλάχιστον ένα τηλέφωνο<BR>';
	}
}
else {
	echo 'Είσαι ήδη Εγγεγραμένος!';
}



?>