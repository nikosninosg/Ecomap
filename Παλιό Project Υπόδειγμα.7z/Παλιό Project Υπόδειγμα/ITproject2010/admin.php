<?php
$admintemp = new template();
$admintemp->load(array(
						  	"ISADMIN" => $_SESSION["admin"],
						  	"NOTLOGEDIN" => _NOTLOGEDIN,
						  	"NOTADDED" => _NOTADDED,
						  	"SUCCSESSFULYADDED" => _SUCCSESSFULYADDED,
						  	"ADSDESC" => _ADS,
						  	"CATDESC" => _CATEGORIES,
						  	"COST" => _COST,
						  	"AREA" => _AREA,
						  	"YEAR" => _YEAR,
						  	"SUPPLIES" => _SUPPLIES,
						  	"FOR" => _FOR,
						  	"SELL" => _SELL,
						  	"RENT" => _RENT,
						  	"PC" => _PC,
						  	"ADDRESS" => _ADDRESS,
						  	"NUM" => _NUM,
						  	"PHOTOS" => _PHOTOS,
						  	"MORE" => _MORE,
						  	"SUBMIT" => _SUBMIT,
						  	"VIEW" => _VIEW
						  ));
						  
if ($_SESSION["admin"]) {
	$header->add(_ADMIN);
	$header->addjs("core/categories.js");
	$header->addjs("core/supplies.js");
	//PENDING ADS
	$result = mysql_query('SELECT * FROM ads,users,categories WHERE ads.uid=users.uid AND ads.category=categories.cid AND ads.approved=0');
	$adnum=mysql_num_rows($result);
	while($ad = mysql_fetch_array($result)) {
		$admintemp->load(array("ADS" => array(array(
																								"AID" => $ad['aid'],
																								"CATEGORY" => $ad['type'],
																								"ADDRESS" => $ad['address'],
					 																			"NUM" => $ad['address_num'],
					 																			"PC" => (is_null($ad['pc'])) ? false : $ad['pc'],
					 																			"COST" => $ad['cost'],
					 																			"AREA" => $ad['area'],
					 																			"YEAR" => (is_null($ad['since'])) ? false : $ad['since'],
					 																			"SELL_RENT" => ($ad['sell_rent']==1) ? _SELL : _RENT,
					 																			"FAVORITE" => false,
					 																			"VLINK" => '?goto=ads&amp;oj='.$ad['aid']
						 																		))
	  								));
	}
	
	$result = mysql_query('SELECT * FROM categories');
	while($cat = mysql_fetch_array($result)) {
		$admintemp->load(array("CATEGORIES" => array(array(
																									"ID" => $cat['cid'],
						 																			"NAME" => $cat['type']
						 																		))
	  								));
	}
		  
	$result = mysql_query('SELECT * FROM supplies');
	while($sup = mysql_fetch_array($result)) {
		$admintemp->load(array("SUPPLY" => array(array(
																									"ID" => $sup['sid'],
						 																			"NAME" => $sup['supply']
						 																		))
	  								));
	}
}
include("header.php");
$admintemp->draw('admin.html');
?>