<?php
//logout



$logoutname=$_SESSION["username"];
session_unset();

$_SESSION['uid'] = 0;
$_SESSION['lang'] = 'gr';
$_SESSION["admin"] = 0;

include("header.php");
echo "Γειά σου ".$logoutname."!";
?>