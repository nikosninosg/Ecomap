<?php
//adds
$header->add(_ADDAD);

$aderror = false;
if ($_SESSION["uid"] AND isset($_POST["address"])) {
	if ($result = mysql_query('INSERT into ads (uid,category,cost,area,since,supplies,sell_rent,pc,address,address_num,lat,lng) VALUES ("'.$_SESSION['uid'].'","'.$_POST['category'].'","'.$_POST['cost'].'","'.$_POST['area'].'",'.(($_POST['since']=='')?'NULL':'"'.$_POST['since'].'"').',"|'.(isset($_POST['supplies'])? implode('|',$_POST['supplies']):'').'|","'.$_POST['sell_rent'].'",'.(($_POST['pc']=='')?'NULL':'"'.$_POST['pc'].'"').',"'.$_POST['address'].'","'.$_POST['address_num'].'",'.$_POST['lat'].','.$_POST['lng'].')')) {
		$aid = mysql_insert_id();
		include("photos.php");
	}
	else {
		$aderror = true;
	}
}

$addtemp = new template();

$addtemp->load(array(
					  	"ISUSER" => $_SESSION["uid"],
					  	"NOTLOGEDIN" => _NOTLOGEDIN,
					  	"ERROR" => $aderror,
					  	"NOTADDED" => _NOTADDED,
					  	"SUCCSESS" => isset($aid),
					  	"SUCCSESSFULYADDED" => _SUCCSESSFULYADDED,
					  	"CATEGORY" => _CATEGORY,
					  	"COST" => _COST,
					  	"AREA" => _AREA,
					  	"YEAR" => _YEAR,
					  	"SUPPLIES" => _SUPPLIES,
					  	"FOR" => _FOR,
					  	"SELL" => _SELL,
					  	"RENT" => _RENT,
					  	"PC" => _PC,
					  	"ADDRESS" => _ADDRESS,
					  	"NUM" => _NUM,
					  	"PHOTOS" => _PHOTOS,
					  	"MORE" => _MORE,
					  	"SUBMIT" => _SUBMIT
					  ));

$result = mysql_query('SELECT * FROM categories');
while($cat = mysql_fetch_array($result)) {
	$addtemp->load(array("CATEGORIES" => array(array(
																								"ID" => $cat['cid'],
					 																			"NAME" => $cat['type']
					 																		))
  								));
}
	  
$result = mysql_query('SELECT * FROM supplies');
while($sup = mysql_fetch_array($result)) {
	$addtemp->load(array("SUPPLY" => array(array(
																								"ID" => $sup['sid'],
					 																			"NAME" => $sup['supply']
					 																		))
  								));
}

if (!isset($aid)) {
	$header->addjs("http://maps.google.com/maps/api/js?sensor=false&language=el");
	$header->addjs("core/add.js");
}
include("header.php");
$addtemp->draw('add.html');
?>