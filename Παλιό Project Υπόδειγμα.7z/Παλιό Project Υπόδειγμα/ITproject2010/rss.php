<?xml version="1.0"?>
<rss version="2.0">
  <channel>
    <title>Αγγελίες Ακινήτων Πάτρας</title>
    <link>http://pellaras.dyndns.org/</link>
    <description>Εργασία στο μάθημα WEB</description>

	<?php
	//rss

	$result = mysql_query('SELECT * FROM ads,users,categories WHERE ads.uid=users.uid AND ads.category=categories.cid AND ads.approved=1 ORDER BY aid  DESC LIMIT 10');
	while($ad = mysql_fetch_array($result)) {
	?>
		<item>
       		<?php echo "\n".'<title>'.$ad['address'].' '.$ad['address_num'].'</title>';
       		echo "\n".'<link>'.'http://pellaras.dyndns.org/?goto=ads&amp;oj='.$ad['aid'].'</link>';
       		echo "\n".'<description>'.$ad['type'].'</description>'."\n";?>
    	</item>
	<?php }

	?>

  </channel>
</rss>