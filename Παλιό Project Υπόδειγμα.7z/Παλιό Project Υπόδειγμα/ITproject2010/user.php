<?php
//user/

if (!isset($_SESSION["username"])){
	if (isset($_POST["username"])) {
		$result = mysql_query('SELECT * FROM users WHERE username="'.$_POST["username"].'" AND password=MD5("'.$_POST["password"].'")');
		if ($user = mysql_fetch_array($result)) {
			$_SESSION["uid"] = $user["uid"];
			$_SESSION["username"] = $user["username"];
			$_SESSION["firstname"] = $user["firstname"];
			$_SESSION["lastname"] = $user["lastname"];
			$_SESSION["email"] = $user["email"];
			$_SESSION["homenumber"] = $user["homenumber"];
			$_SESSION["mobilephone"] = $user["mobilephone"];
			$_SESSION["fax"] = $user["fax"];
			$_SESSION["worknumber"] = $user["worknumber"];
			$_SESSION["admin"] = $user["admin"];
		}
	}
}

$usertemp = new template();
$usertemp->load(array(
						  	"ISUSER" => $_SESSION["uid"],
						  	"ISADMIN" => $_SESSION["admin"],
						  	"NOTLOGEDIN" => _NOTLOGEDIN,
						  	"PERSONALINFO" => _PERSONALINFO,
						  	"MYADS" => _MYADS,
						  	"MYFAV" => _MYFAV,
						  	"YEAR" => _YEAR,
						  	"VIEW" => _VIEW,
						  	"PC" => _PC,
						  	"PENDING" => _PENDING,
						  	"NOADS" => _NOADS,
						  	"ADD" => _ADDAD,
						  	"ADDLINK" => "?goto=ads&amp;do=add",
						  ));

if (!isset($_SESSION["username"])){
	$header->add(_ACCOUNT);
	include("header.php");
	echo isset($user)? 'Το username ή το password είναι λανθασμένο<br>' : '';
	echo '<form name="login" method="post" action="">';
	echo 'Username:  <input type="text" name="username"><br>';
	echo 'Κωδικός: <input type="password" name="password"><br>';
	echo '<input type="submit" value="Σύνδεση">';
	echo '</form>';
	echo '<br><a href="?goto=register">Εγγραφίτε εδώ</a>';
}
else {
	$header->add(_ACCOUNT);
	$header->addjs("core/register.js");
	$header->addjs("core/useredit.js");
	$header->addjs("core/favorite.js");
	include("header.php");
	$usertemp->load(array(
						  	"USERNAME" => $_SESSION["username"],
						  	"USERNAMEDESC" => _USERNAME,
						  	"EMAIL" => $_SESSION['email'],
						  	"EMAILDESC" => _EMAIL,
						  	"FIRSTNAME" => is_null($_SESSION['firstname']) ? false : $_SESSION['firstname'],
						  	"FIRSTNAMEDESC" => _FISTNAME,
						  	"LASTNAME" => is_null($_SESSION['lastname']) ? false : $_SESSION['lastname'],
						  	"LASTNAMEDESC" => _LASTNAME,
						  	"HOMENUMBER" => is_null($_SESSION['homenumber']) ? false : $_SESSION['homenumber'],
						  	"HOMENUMBERDESC" => _HOMENUMBER,
						  	"MOBILEPHONE" => is_null($_SESSION['mobilephone']) ? false : $_SESSION['mobilephone'],
						  	"MOBILEPHONEDESC" => _MOBILEPHONE,
						  	"FAX" => is_null($_SESSION['fax']) ? false : $_SESSION['fax'],
						  	"FAXDESC" => _FAX,
						  	"WORKNUMBER" => is_null($_SESSION['worknumber']) ? false : $_SESSION['worknumber'],
						  	"WORKNUMBERDESC" => _WORKNUMBER,
						  ));
	
	$result = mysql_query('SELECT * FROM ads,categories WHERE ads.category=categories.cid AND ads.uid='.$_SESSION["uid"].' AND (ads.approved=0 OR ads.approved=1)');
	if (mysql_num_rows($result)) {
		$tuads=true;
		while($ad = mysql_fetch_array($result)) {
			$usertemp->load(array("UADS" => array(array(
																								"AID" => $ad['aid'],
																								"PENDING" => !($ad['approved']),
																								"CATEGORY" => $ad['type'],
																								"ADDRESS" => $ad['address'],
					 																			"NUM" => $ad['address_num'],
					 																			"PC" => (is_null($ad['pc'])) ? false : $ad['pc'],
					 																			"COST" => $ad['cost'],
					 																			"AREA" => $ad['area'],
					 																			"YEAR" => (is_null($ad['since'])) ? false : $ad['since'],
					 																			"SELL_RENT" => ($ad['sell_rent']==1) ? _SELL : _RENT,
					 																			"VLINK" => '?goto=ads&amp;oj='.$ad['aid']
						 																		))
	  								));
		}
		
	}
	else {
		$tuads=false;
	}
	
	$result = mysql_query('SELECT * FROM ads,users,categories WHERE ads.uid=users.uid AND ads.category=categories.cid AND ads.aid IN (SELECT aid FROM favorites WHERE uid='.$_SESSION["uid"].') AND ads.approved=1');
	if (mysql_num_rows($result)) {
		$tfads=true;
		while($ad = mysql_fetch_array($result)) {
			$usertemp->load(array("FADS" => array(array(
																								"AID" => $ad['aid'],
																								"CATEGORY" => $ad['type'],
																								"ADDRESS" => $ad['address'],
					 																			"NUM" => $ad['address_num'],
					 																			"PC" => (is_null($ad['pc'])) ? false : $ad['pc'],
					 																			"COST" => $ad['cost'],
					 																			"AREA" => $ad['area'],
					 																			"YEAR" => (is_null($ad['since'])) ? false : $ad['since'],
					 																			"SELL_RENT" => ($ad['sell_rent']==1) ? _SELL : _RENT,
					 																			"VLINK" => '?goto=ads&amp;oj='.$ad['aid']
						 																		))
	  								));
		}
		
	}
	else {
		$tfads=false;
	}
	
	$usertemp->load(array(
						  	"TUADS" => $tuads,
						  	"TFADS" => $tfads
						  ));
	
	$usertemp->draw('user.html');
	
	
	/*
	echo isset($user)? 'Επιτιχία συνδεσής!<br>' : '';
	echo 'Καλωσόρισες '.$_SESSION["username"];
	echo '<br><a href="?goto=logout">Αποσύνδεση</a> <a href="?goto=user&amp;do=edit">Επεξεργασία Λογαριασμου</a><br>';
	echo '<br>Αγγελίες μου:<br>';
	$result = mysql_query('SELECT * FROM ads WHERE uid='.$_SESSION["uid"]);
	$ads=0;
	while($ad = mysql_fetch_array($result)) {
		$ads++;
  	echo ($ad['approved']?'':'{pending}').$ad['address'].' '.$ad['address_num'].' ['.$ad['cost'].'€] <a href="?goto=ads&amp;oj='.$ad['aid'].'">view</a> <a href="?goto=ads&do=edit&amp;oj='.$ad['aid'].'">edit</a><br>';
  }
  if (!$ads) { echo 'Kamia aggelia<br>'; }
  echo '<a href="?goto=ads&amp;do=add">Prosthese</a>';
  
  echo '<br><br>Agapimenes:<br>';
	$result = mysql_query('SELECT * FROM ads WHERE aid IN (SELECT aid FROM favorites WHERE uid='.$_SESSION["uid"].') AND approved=1');
	$ads=0;
	while($ad = mysql_fetch_array($result)) {
		$ads++;
  	echo $ad['address'].' '.$ad['address_num'].' ['.$ad['cost'].'€] <a href="?goto=ads&amp;oj='.$ad['aid'].'">view</a><br>';
  }
  if (!$ads) { echo 'Kamia agapimeni<br>'; }
  */
}

?>