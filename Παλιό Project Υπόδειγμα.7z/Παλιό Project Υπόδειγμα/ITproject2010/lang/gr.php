<?php
/**************************
  SYSTEM
**************************/
define('_SITETITLE','Αγγελίες Ακινήτων Πάτρας');
define('_TITLESEPERATOR',' >> ');
define('_RECENT','Πρόσφατες Αγγελίες');
define('_POPULAR','Δημοφιλείς Αγγελίες');
//define('_','');

/**************************
  INDEX
**************************/
define('_HOMEPAGE','Κεντρική Σελίδα');
define('_HOME','Κεντρική');
define('_OR','ή');
//define('_','');

/**************************
  FOODER
**************************/
define('_COPYRIGHT','Copyright');
define('_ALLRIGHTS','All rights reserved');
//define('_','');
//define('_','');
//define('_','');

/**************************
  USER
**************************/
define('_ACCOUNT','Λογαριασμός');
define('_LOGIN','Συνδεθείτε');
define('_REGISTER','Εγγραφείτε');
define('_LOGOUT','Αποσύνδεση');
define('_NOTLOGEDIN','Δεν είστε συνδεδεμένος');
define('_USERNAME','Username');
define('_EMAIL','E-mail');
define('_FISTNAME','Όνομα');
define('_LASTNAME','Επίθετο');
define('_HOMENUMBER','Σπιτιού');
define('_MOBILEPHONE','Κινητό');
define('_FAX','Φαξ');
define('_WORKNUMBER','Εργασίας');
define('_PERSONALINFO','Προσωπικές Πληροφορίες');
define('_MYADS','Οι Αγγελίες μου');
define('_MYFAV','Οι Αγαπημένες μου');
define('_USERINFO','Πληροφορίες Χρήστη');

/**************************
  ADS
**************************/
define('_SEARCH','Αναζήτηση');
define('_NOTFOUND','Δεν Υπάρχει');
define('_CATEGORY','Κατηγορία');
define('_CATEGORIES','Κατηγορίες');
define('_COST','Κόστος');
define('_AREA','Τετραγωνικά');
define('_YEAR','Έτος Κατασκευής');
define('_SUPPLIES','Παροχές');
define('_FOR','Προς');
define('_SELL','Πώληση');
define('_RENT','Ενοικίαση');
define('_ADDRESS','Διεύθυνση');
define('_NUM','Αρ.');
define('_PHOTOS','Φωτογραφίες');
define('_PC','TK');
define('_ADS','Αγγελίες');
define('_PREVIOUS','Προηγούμενες');
define('_NEXT','Επόμενες');
define('_SHOWING','Εμφάνιση');
define('_OF','από');
define('_INFO','Πληροφορίες Αγγελίας');
define('_EDIT','Επεξεργασία');
define('_PENDINGAPPROVAL','Η αγγελία σας βρίσκετε σε αναμονή για να εγκριθεί!');

/**************************
  ADD
**************************/
define('_ADDAD','Προσθήκη Αγγελίας');
define('_NOTADDED','Αποτυχία καταχώρησης');
define('_SUCCSESSFULYADDED','Η αγγελία καταχωρήθηκε με επιτυχία');
define('_MORE','Επιπλέον');
define('_SUBMIT','Καταχώρηση');
define('_NOADS','Καμία Αγγελία');
//define('_','');
//define('_','');

/**************************
  ADMIN
**************************/
define('_ADMIN','Διαχείριση');
define('_VIEW','Δες');
define('_PENDING','Σε αναμονή');
//define('_','');
//define('_','');

?>