<?php
//api

include("core/system.php");

if (isset($_GET['do'])) {
	//AGGELIES
	if (strcmp($_GET['do'],'ads')==0) {
		if (isset($_GET['address']) AND strlen($_GET['address'])>0) {
			$result = mysql_query('SELECT * FROM address WHERE street LIKE "'.$_GET['address'].'%" OR street_el LIKE "'.$_GET['address'].'%" OR street LIKE "% '.$_GET['address'].'%" OR street_el LIKE "% '.$_GET['address'].'%" ORDER BY street ASC');
			if (mysql_num_rows($result)) {
				while($address = mysql_fetch_array($result)) {
		  		echo $address['street_el'].'<br>';
		  	}
			}
		}
	}
	//FAVORITES
	elseif (strcmp($_GET['do'],'fav')==0) {
		if ($_SESSION['uid'] AND isset($_GET['ad'])) {
			$uid=$_SESSION['uid'];
			$aid=$_GET['ad'];
			//ELEGXOS AN YPARXEI H AGGELIA
			if (mysql_num_rows(mysql_query('SELECT * FROM ads WHERE aid='.$aid.' AND approved=1'))) {
				//ELEGOS AN EINAI IDI APOTHIKEVMENI STIS AGAPIMENES
				if (mysql_num_rows(mysql_query('SELECT * FROM favorites WHERE aid='.$aid.' AND uid='.$uid))) {
					if (mysql_query('DELETE FROM favorites WHERE aid='.$aid.' AND uid='.$uid)) {
						echo 0;
					}
					else {
						echo 1;
					}
				}
				//DIAFORETIKA AFERESE
				else {
					if (mysql_query('INSERT INTO favorites (aid,uid) VALUES ('.$aid.','.$uid.')')) {
						echo 1;
					}
					else {
						echo 0;
					}
				}
			}
			else {
				echo -1;
			}
		}
		else {
			echo -1;
		}
	}
	//MARKERS
	elseif (strcmp($_GET['do'],'mark')==0) {
		header('Content-type: text/xml; charset=UTF-8');
		echo '<?xml version="1.0" encoding="UTF-8"?>';
		echo '<markers>';
		$result = mysql_query('SELECT * FROM ads,users,categories WHERE ads.uid=users.uid AND ads.category=categories.cid AND ads.approved=1 ORDER BY aid  DESC LIMIT 5');
		while($ad = mysql_fetch_array($result)) {
			echo '<marker address="'.$ad['address'].' '.$ad['address_num'].'" lat="'.$ad['lat'].'" lng="'.$ad['lng'].'" type="recent" />';
  	}
		$result = mysql_query('SELECT * FROM ads,users,categories WHERE ads.uid=users.uid AND ads.category=categories.cid AND ads.approved=1 ORDER BY views  DESC, aid ASC LIMIT 5');
		while($ad = mysql_fetch_array($result)) {
			echo '<marker address="'.$ad['address'].' '.$ad['address_num'].'" lat="'.$ad['lat'].'" lng="'.$ad['lng'].'" type="popular" />';
  	}
		echo '</markers>';
	}
	//SEARCH
	elseif (strcmp($_GET['do'],'search')==0) {
		//print_r($_POST);
		$q="FROM ads,users,categories WHERE ads.uid=users.uid AND ads.category=categories.cid AND ads.approved=1";
		if (isset($_POST['categories'])) {
			$q.=" AND (category=".implode(" OR category=", $_POST['categories']).")";
		}
		if (!empty($_POST['cost'])) {
			if (empty($_POST['ecost'])) {
				$q.=" AND cost=".$_POST['cost'];
			}
			else {
				$q.=" AND cost >= ".$_POST['cost']." AND cost <= ".$_POST['ecost'];
			}
		}
		if (!empty($_POST['area'])) {
			if (empty($_POST['earea'])) {
				$q.=" AND area=".$_POST['area'];
			}
			else {
				$q.=" AND area >= ".$_POST['area']." AND area <= ".$_POST['earea'];
			}
		}
		if (!empty($_POST['since'])) {
			if (empty($_POST['esince'])) {
				$q.=" AND since=".$_POST['since'];
			}
			else {
				$q.=" AND since >= ".$_POST['since']." AND since <= ".$_POST['esince'];
			}
		}
		if (isset($_POST['sell_rent'])) {
			$q.=" AND (sell_rent=".implode(" OR sell_rent=", $_POST['sell_rent']).")";
		}
		if (isset($_POST['supplies'])) {
			$q.=" AND supplies LIKE \"%|".implode("|%\" AND supplies LIKE \"%|", $_POST['supplies'])."|%\"";
		}
		if (isset($_POST['photos'])) {
			$q.=" AND ads.aid IN (SELECT DISTINCT aid FROM photos)";
		}
		$q.=" ORDER BY aid  DESC";
		$perpage=5;
		if (isset($_POST['page'])) {
			$page=intval($_POST['page']);
		}
		else {
			$page=1;
		}
		$num=mysql_result(mysql_query("SELECT COUNT(*) ".$q),0);
		if ($num) {
			$totalpage=ceil($num/$perpage);
		}
		else {
			$totalpage=1;
		}
		if ($page < 1) {
			$page = 1;
		}
		elseif ($page > $totalpage) {
			$page=$totalpage;
		}
		$startad=($page-1)*$perpage;
		$q.=" LIMIT $startad,$perpage";
		$ads=mysql_query("SELECT * ".$q);
		//echo "<br><br>$num<br>";
		$adstemp = new template();
		$adstemp->load(array(
						  	"ISUSER" => $_SESSION["uid"],
						  	"COST" => _COST,
						  	"AREA" => _AREA,
						  	"YEAR" => _YEAR,
						  	"SUPPLIES" => _SUPPLIES,
						  	"FOR" => _FOR,
						  	"PC" => _PC,
						  	"ADS" => array(),
						  	"TOTAL" => $num,
						  	"SHOWING" => _SHOWING,
						  	"OF" => _OF,
						  	"PREVIOUS" => _PREVIOUS,
						  	"NEXT" => _NEXT,
						  	"STARTAD" => $num ? $startad+1 : 0,
						  	"ENDAD" => $startad+mysql_num_rows($ads),
						  	"PREVIOUSPAGE" => ($page > 1) ? $page-1 : 0,
						  	"NEXTPAGE" => ($page < $totalpage) ? $page+1 : 0
						  ));
		$sups=mysql_query("SELECT * FROM supplies");
		while($sup = mysql_fetch_array($sups)) {
			$supp[$sup['sid']]=$sup['supply'];
		}
		if ($_SESSION["uid"]) {
			$fav=mysql_query("SELECT aid FROM favorites WHERE uid=".$_SESSION["uid"]);
			while($favs = mysql_fetch_array($fav)) {
				$favorites[$favs['aid']]=true;
			}
		}
		while($ad = mysql_fetch_array($ads)) {
			$supplies = array();
			if (strlen($ad['supplies'])>2) {
	  		$su=explode("|",substr($ad['supplies'],1,strlen($ad['supplies'])-2));
	  		foreach($su AS $sid) {
	  			if (isset($supp[$sid])) {
	  				$supplies[] = array ("NAME" => $supp[$sid]);
	  			}
	  		}
  		}
			$adstemp->load(array("ADS" => array(array(
																								"AID" => $ad['aid'],
																								"CATEGORY" => $ad['type'],
																								"ADDRESS" => $ad['address'],
					 																			"NUM" => $ad['address_num'],
					 																			"PC" => (is_null($ad['pc'])) ? false : $ad['pc'],
					 																			"COST" => $ad['cost'],
					 																			"AREA" => $ad['area'],
					 																			"YEAR" => (is_null($ad['since'])) ? false : $ad['since'],
					 																			"SELL_RENT" => ($ad['sell_rent']==1) ? _SELL : _RENT,
					 																			"SUPPLIES" => $supplies,
					 																			"FAVORITE" => isset($favorites[$ad['aid']]),
					 																			"VLINK" => '?goto=ads&amp;oj='.$ad['aid']
					 																		))
  								));
  		
		}
		$adstemp->draw('search.html');
	}
	//APROVE
	elseif (strcmp($_GET['do'],'approve')==0) {
		if ($_SESSION['admin'] AND isset($_GET['ad'])) {
			$aid=intval($_GET['ad']);
			if (mysql_query("UPDATE ads SET approved=1 WHERE aid=$aid")) {
				echo 1;
			}
			else {
				echo 0;
			}
		}
		else {
			echo 0;
		}
	}
	//ADD CATEGORY
	elseif (strcmp($_GET['do'],'addcat')==0) {
		if ($_SESSION['admin'] AND isset($_POST['value'])) {
			$value = $_POST['value'];
			if (mysql_query('INSERT INTO categories (type) VALUES ("'.$value.'")')) {
				echo mysql_insert_id();
			}
			else {
				echo 0;
			}
		}
		else {
			echo 0;
		}
	}
	//EDIT CATEGORY
	elseif (strcmp($_GET['do'],'editcat')==0) {
		if ($_SESSION['admin'] AND isset($_POST['value']) AND isset($_GET['cid'])) {
			$value = $_POST['value'];
			$cid = intval($_GET['cid']);
			if (mysql_query('UPDATE categories SET type="'.$value.'" WHERE cid='.$cid)) {
				echo 1;
			}
			else {
				echo 0;
			}
		}
		else {
			echo 0;
		}
	}
	//DELETE CATEGORY
	elseif (strcmp($_GET['do'],'delcat')==0) {
		if ($_SESSION['admin'] AND isset($_GET['cid'])) {
			$cid = intval($_GET['cid']);
			if (mysql_query('DELETE FROM categories WHERE cid='.$cid)) {
				echo 1;
			}
			else {
				echo 0;
			}
		}
		else {
			echo 0;
		}
	}
	//ADD SUPPLY
	elseif (strcmp($_GET['do'],'addsup')==0) {
		if ($_SESSION['admin'] AND isset($_POST['value'])) {
			$value = $_POST['value'];
			if (mysql_query('INSERT INTO supplies (supply) VALUES ("'.$value.'")')) {
				echo mysql_insert_id();
			}
			else {
				echo 0;
			}
		}
		else {
			echo 0;
		}
	}
	//EDIT SUPPLY
	elseif (strcmp($_GET['do'],'editsup')==0) {
		if ($_SESSION['admin'] AND isset($_POST['value']) AND isset($_GET['sid'])) {
			$value = $_POST['value'];
			$sid = intval($_GET['sid']);
			if (mysql_query('UPDATE supplies SET supply="'.$value.'" WHERE sid='.$sid)) {
				echo 1;
			}
			else {
				echo 0;
			}
		}
		else {
			echo 0;
		}
	}
	//DELETE SUPPLY
	elseif (strcmp($_GET['do'],'delsup')==0) {
		if ($_SESSION['admin'] AND isset($_GET['sid'])) {
			$sid = intval($_GET['sid']);
			if (mysql_query('DELETE FROM supplies WHERE sid='.$sid)) {
				echo 1;
			}
			else {
				echo 0;
			}
		}
		else {
			echo 0;
		}
	}
	//EDIT USER
	elseif (strcmp($_GET['do'],'edituser')==0) {
		//print_r($_POST);
		if (isset($_POST['uid']) AND $_SESSION['uid'] AND ($_SESSION['admin'] OR $_POST['uid']==$_SESSION['uid'])) {
			$sucs=false;
			$uid = intval($_POST['uid']);
			$firstname = $_POST['firstname'];
			$lastname = $_POST['lastname'];
			$email = $_POST['email'];
			$homenumber = $_POST['homenumber'];
			$mobilephone = $_POST['mobilephone'];
			$fax = $_POST['fax'];
			$worknumber = $_POST['worknumber'];
			$oldpassword = $_POST['oldpassword'];
			$password = $_POST['password'];
			$q='UPDATE users SET email="'.$email.'", firstname=';
			$q .= ($firstname=='') ? 'NULL' : '"'.$firstname.'"' ;
			$q .= ', lastname=';
			$q .= ($lastname=='') ? 'NULL' : '"'.$lastname.'"' ;
			$q .= ', homenumber=';
			$q .= ($homenumber=='') ? 'NULL' : '"'.$homenumber.'"' ;
			$q .= ', mobilephone=';
			$q .= ($mobilephone=='') ? 'NULL' : '"'.$mobilephone.'"' ;
			$q .= ', fax=';
			$q .= ($fax=='') ? 'NULL' : '"'.$fax.'"' ;
			$q .= ', worknumber=';
			$q .= ($worknumber=='') ? 'NULL' : '"'.$worknumber.'"' ;
			$q .= ' WHERE uid='.$uid;
			//echo $q;
			if (mysql_query($q)) {
				if ($oldpassword=='') {
					$sucs=true;
					echo 1;
				}
				else {
					if (mysql_num_rows(mysql_query('SELECT * FROM users WHERE uid="'.$uid.'" AND password=MD5("'.$oldpassword.'")'))) {
						if (mysql_query('UPDATE users SET password=MD5("'.$password.'") WHERE uid='.$uid)) {
							$sucs=true;
							echo 1;
						}
						else {
							$sucs=true;
							echo 2;
						}
					}
					else {
						$sucs=true;
						echo 2;
					}
				}
				if ($sucs AND $uid==$_SESSION['uid']) {
					$_SESSION["firstname"] = $firstname;
					$_SESSION["lastname"] = $lastname;
					$_SESSION["email"] = $email;
					$_SESSION["homenumber"] = $homenumber;
					$_SESSION["mobilephone"] = $mobilephone;
					$_SESSION["fax"] = $fax;
					$_SESSION["worknumber"] = $worknumber;
				}
			}
			else {
				echo 0;
			}
		}
		else {
			echo 0;
		}
	}
	//EDIT ADVERT
	elseif (strcmp($_GET['do'],'editad')==0) {
		//print_r($_POST);
		if ($_SESSION['admin']) {
			$sucs=false;
			$aid = intval($_POST['aid']);
			$cid = intval($_POST['category']);
			$cost = intval($_POST['cost']);
			$area = intval($_POST['area']);
			$since = intval($_POST['since']);
			$supplies = isset($_POST['supplies']) ? implode('|',$_POST['supplies']) : '';
			$sell_rent = intval($_POST['sell_rent']);
			$pc = intval($_POST['pc']);
			$address = $_POST['address'];
			$num = intval($_POST['address_num']);
			$lat = $_POST['lat'];
			$lng = $_POST['lng'];
			$q='UPDATE ads SET category='.$cid.', cost='.$cost.', area='.$area.', supplies="|'.$supplies.'|", sell_rent='.$sell_rent.', address="'.$address.'", address_num='.$num.', lat="'.$lat.'", lng="'.$lng.'", since=';
			$q .= ($since=='') ? 'NULL' : '"'.$since.'"' ;
			$q .= ', pc=';
			$q .= ($pc=='') ? 'NULL' : '"'.$pc.'"' ;
			$q .= ' WHERE aid='.$aid;
			//echo $q;
			if (mysql_query($q)) {
				echo 1;
			}
			else {
				echo 0;
			}
		}
		else {
			echo 0;
		}
	}
	//DELETE ADVERT
	elseif (strcmp($_GET['do'],'deletead')==0) {
		if (isset($_GET['ad'])) {
			$aid=intval($_GET['ad']);
			$ad=mysql_fetch_array(mysql_query('SELECT * FROM ads,users,categories WHERE ads.aid='.$aid.' AND ads.category=categories.cid AND ads.uid=users.uid'));
			if ($_SESSION['uid']==$ad['uid']) {
				if (mysql_query("UPDATE ads SET approved=2 WHERE aid=$aid")) {
					echo 1;
				}
				else {
					echo 0;
				}
			}
			else {
				echo 0;
			}
		}
		else {
			echo 0;
		}
	}
	elseif (strcmp($_GET['do'],'getaddresses')==0) {
		//include("core/get_addresses.php");
	}
}

mysql_close($db);
?>