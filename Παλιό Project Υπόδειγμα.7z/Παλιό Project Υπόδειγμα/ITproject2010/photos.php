<?php
foreach ($_FILES as $photo => $value) {
	//echo "<br><br>".$photo."<br><br>";
if (($_FILES[$photo]["type"] == "image/jpeg")&&($_FILES[$photo]["size"] < 50000))
  {
  if ($_FILES[$photo]["error"] > 0)
    {
    //echo "Return Code: " . $_FILES[$photo]["error"] . "<br />";
    }
  else
    {
    //echo "Upload: " . $_FILES[$photo]["name"] . "<br />";
    //echo "Type: " . $_FILES[$photo]["type"] . "<br />";
    //echo "Size: " . ($_FILES[$photo]["size"] / 1024) . " Kb<br />";
    //echo "Temp file: " . $_FILES[$photo]["tmp_name"] . "<br />";

    if (file_exists("photos/".$aid."/" . $_FILES[$photo]["name"]))
      {
      //echo $_FILES[$photo]["name"] . " already exists. <br>";
      }
    else
      {
      if (!is_dir("photos/".$aid)) {
      	mkdir("photos/".$aid);
      }
      move_uploaded_file($_FILES[$photo]["tmp_name"],
      "photos/" .$aid."/". $_FILES[$photo]["name"]);
      //echo "Stored in: " . "photos/" .$aid."/". $_FILES[$photo]["name"]."<br>";
      mysql_query('INSERT into photos (aid,filename) VALUES ("'.$aid.'","'.$_FILES[$photo]["name"].'")');
      }
    }
  }
else
  {
  //echo "Invalid file";
  }
}
?>