<?php
define('HEADER',true);

$headertemp = new template();
//$header->addjs("core/getaddresses.js");
$headertemp->load(array(
					  	"PAGETITLE" => $header->title,
					  	"SCRIPTS" => $header->js,
					  	"NOTHOME" => isset($_GET['goto']),
					  	"ISUSER" => $_SESSION["uid"],
					  	"ISADMIN" => $_SESSION["admin"],
					  	"HOME" => _HOME,
					  	"SEARCH" => _SEARCH,
					  	"ADD" => _ADDAD,
					  	"ACCOUNT" => _ACCOUNT,
					  	"LOGIN" => _LOGIN,
					  	"LOGOUT" => _LOGOUT,
					  	"REGISTER" => _REGISTER,
					  	"OR" => _OR,
					  	"ADMIN" => _ADMIN,
					  	"PENDING" => _PENDING,
					  	"PENDINGNUM" => mysql_num_rows(mysql_query('SELECT * FROM ads,users,categories WHERE ads.uid=users.uid AND ads.category=categories.cid AND ads.approved=0')),
					  	"SEARCHLINK" => '?goto=ads',
					  	"ADDLINK" => '?goto=ads&do=add',
					  	"ACCOUNTLINK" => '?goto=user',
					  	"REGISTERLINK" => '?goto=register',
					  	"LOGOUTLINK" => '?goto=logout',
					  	"ADMINLINK" => '?goto=admin',
					  ));

if (isset($_SESSION["username"])){
	$headertemp->load(array(
					  	"LASTNAME" => $_SESSION["lastname"],
					  	"FIRSTNAME" => $_SESSION["firstname"],
					  	"USERNAME" => $_SESSION["username"],
					  ));
}

$headertemp->draw('header.html');
?>