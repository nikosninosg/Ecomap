<?php

$foodertemp = new template();
$foodertemp->load(array(
					  	"COPYRIGHT" => _COPYRIGHT.' &copy; 2010',
					  	"ALLRIGHTS" => _ALLRIGHTS,
					  ));

$foodertemp->draw('fooder.html');
?>