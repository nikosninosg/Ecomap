<?php
//ads



if (isset($_GET["oj"])) {
	$aid=intval($_GET["oj"]);
	$result = mysql_query('SELECT * FROM ads,users,categories WHERE ads.aid='.$aid.' AND ads.category=categories.cid AND ads.uid=users.uid'.($_SESSION["admin"]?' AND (ads.approved=0 OR ads.approved=1)':' AND (ads.approved=1'.($_SESSION["uid"] ? ' OR (ads.uid='.$_SESSION["uid"].' AND ads.approved=0)' : '').')'));
	if ($ad = mysql_fetch_array($result)) {
		
		if ($ad['uid']!=$_SESSION["uid"] AND $ad['approved']) {
			mysql_query('UPDATE ads SET views = views+1 WHERE aid ='.$ad['aid']);
		}
		
		$header->add($ad['address'].' '.$ad['address_num']);
		$header->addjs("core/favorite.js");
		$header->addjs("core/approve.js");
		$header->addjs("core/delete.js");
		$header->addjs("http://maps.google.com/maps/api/js?sensor=false&language=el");
		$header->addjs("core/add.js");
		include("header.php");
		$adtemp = new template();
		$result = mysql_query('SELECT * FROM categories');
		while($cat = mysql_fetch_array($result)) {
			$adtemp->load(array("CATEGORIES" => array(array(
																										"ID" => $cat['cid'],
							 																			"NAME" => $cat['type'],
							 																			"SELECTED" => ($cat['cid']==$ad['cid']) ? true : false
							 																		))
		  								));
		}
		
		if (strlen($ad['supplies'])>2) {
	  	$su=explode("|",substr($ad['supplies'],1,strlen($ad['supplies'])-2));
  	}
  	else {
  		$su=array();
  	}
		$supplies = array();
		$result = mysql_query('SELECT * FROM supplies');
		while($sup = mysql_fetch_array($result)) {
			if (in_array($sup['sid'],$su)) {
				$supplies[] = array ("NAME" => $sup['supply']);
			}
			$adtemp->load(array("SUPPLY" => array(array(
																										"ID" => $sup['sid'],
							 																			"NAME" => $sup['supply'],
							 																			"SELECTED" => in_array($sup['sid'],$su)
							 																		))
		  								));
		}
		
		$adtemp->load(array(
							  	"ISUSER" => $_SESSION["uid"],
								"OWNER" => ($_SESSION["uid"]==$ad['uid']),
							  	"ISADMIN" => $_SESSION["admin"],
							  	"AID" => $ad['aid'],
									"CATEGORY" => $ad['type'],
									"ADDRESS" => $ad['address'],
					 				"NUM" => $ad['address_num'],
					 				"PC" => (is_null($ad['pc'])) ? false : $ad['pc'],
					 				"COST" => $ad['cost'],
					 				"AREA" => $ad['area'],
					 				"YEAR" => (is_null($ad['since'])) ? false : $ad['since'],
					 				"SELL_RENT" => ($ad['sell_rent']==1) ? _SELL : _RENT,
					 				"ISSELL" => ($ad['sell_rent']==1) ? true : false,
					 				"ISRENT" => ($ad['sell_rent']==1) ? false : true,
					 				"SUPPLIES" => $supplies,
					 				"FAVORITE" => mysql_num_rows(mysql_query('SELECT * FROM favorites WHERE aid='.$ad['aid'].' AND uid='.$_SESSION["uid"])),
					 				"PENDING" => !($ad['approved']),
							  	"INFO" => _INFO,
							  	"LAT" => $ad['lat'],
							  	"LNG" => $ad['lng'],
							  	"PENDINGAPPROVAL" => _PENDINGAPPROVAL,
							  	
							  	"USERINFO" => _USERINFO,
							  	"USERNAME" => $ad['username'],
							  	"USERNAMEDESC" => _USERNAME,
							  	"EMAIL" => $ad['email'],
							  	"EMAILDESC" => _EMAIL,
							  	"FIRSTNAME" => is_null($ad['firstname']) ? false : $ad['firstname'],
							  	"FIRSTNAMEDESC" => _FISTNAME,
							  	"LASTNAME" => is_null($ad['lastname']) ? false : $ad['lastname'],
							  	"LASTNAMEDESC" => _LASTNAME,
							  	"HOMENUMBER" => is_null($ad['homenumber']) ? false : $ad['homenumber'],
							  	"HOMENUMBERDESC" => _HOMENUMBER,
							  	"MOBILEPHONE" => is_null($ad['mobilephone']) ? false : $ad['mobilephone'],
							  	"MOBILEPHONEDESC" => _MOBILEPHONE,
							  	"FAX" => is_null($ad['fax']) ? false : $ad['fax'],
							  	"FAXDESC" => _FAX,
							  	"WORKNUMBER" => is_null($ad['worknumber']) ? false : $ad['worknumber'],
							  	"WORKNUMBERDESC" => _WORKNUMBER,
						  	
						  	
							  	"NOTLOGEDIN" => _NOTLOGEDIN,
							  	"NOTADDED" => _NOTADDED,
							  	"SUCCSESSFULYADDED" => _SUCCSESSFULYADDED,
							  	"CATEGORYDESC" => _CATEGORY,
							  	"COSTDESC" => _COST,
							  	"AREADESC" => _AREA,
							  	"YEARDESC" => _YEAR,
							  	"SUPPLIESDESC" => _SUPPLIES,
							  	"FOR" => _FOR,
							  	"SELL" => _SELL,
							  	"RENT" => _RENT,
							  	"PCDESC" => _PC,
							  	"ADDRESSDESC" => _ADDRESS,
							  	"NUMDESC" => _NUM,
							  	"PHOTOS" => _PHOTOS,
							  	"MORE" => _MORE,
							  	"SUBMIT" => _SUBMIT,
							  	"EDIT" => _EDIT,
							  ));
		
		$result = mysql_query('SELECT * FROM photos WHERE aid='.$ad['aid']);
		$adtemp->load(array(
							  	"PICSNUM" => mysql_num_rows($result),
							  ));
  	while($photo = mysql_fetch_array($result)) {
  		$adtemp->load(array("PIC" => array(array(
																										"LINK" => 'photos/'.$ad['aid'].'/'.$photo['filename'],
							 																		))
		  								));
  		//echo '<img src = "photos/'.$ad['aid'].'/'.$photo['filename'].'" alt = "'.$photo['filename'].'"><br>';
  	}
			
		
		
		$adtemp->draw('ad.html');
	}
	else {
  	$header->add(_NOTFOUND);
		include("header.php");
  	echo "Δεν υπάρχει η αγγελία";
  }
	
	/*$result = mysql_query('SELECT * FROM ads,users,categories WHERE ads.aid='.$_GET["oj"].' AND ads.category=categories.cid AND ads.uid=users.uid'.($_SESSION["admin"]?'':' AND (ads.approved=1'.(isset($_SESSION["uid"])?' OR ads.uid='.$_SESSION["uid"]:'').')'));
	if ($ad = mysql_fetch_array($result)) {
		if ($ad['uid']!=$_SESSION["uid"] AND $ad['approved']) {
			mysql_query('UPDATE ads SET views = views+1 WHERE aid ='.$ad['aid']);
		}
		$header->add($ad['address'].' '.$ad['address_num']);
		$header->addjs("core/favorite.js");
		$header->addjs("core/approve.js");
		include("header.php");
		if (!$ad['approved']) {
			echo $_SESSION["admin"]?'<div id="approve" onclick="approve('.$ad['aid'].',this)" style="color:red; cursor:pointer">Approve</div>':'Η αγγελία είναι σε αναμονή για να εγκριθεί από κάποιο διαχειριστή';
		}
		if (mysql_num_rows(mysql_query('SELECT * FROM favorites WHERE aid='.$ad['aid'].' AND uid='.$_SESSION["uid"]))) {
			echo '<div id="favorite" onclick="favorite('.$ad['aid'].',this)" style="color:red; cursor:pointer"><img src = "template/img/favourite.png"></div>';
		}
		else {
			echo '<div id="favorite" onclick="favorite('.$ad['aid'].',this)" style="color:red; cursor:pointer"><img src = "template/img/unfavourite.png"></div>';
		}
  	echo '<br>Διεύθυνση: '.$ad['address'].' '.$ad['address_num'].'<br>';
  	echo 'Κόστος: '.$ad['cost'].'€<br>';
  	echo 'Χρήστης: '.$ad['username'].'<br>';
  	echo 'Κατηγορία: '.$ad['type'].'<br>';
  	echo 'Τηλέφωνα: '.$ad['homenumber'].'|'.$ad['mobilephone'].'|'.$ad['fax'].'|'.$ad['worknumber'].'<br>';
  	if ($ad['uid']==$_SESSION["uid"] OR $_SESSION["admin"]) {
  		echo '<a href=?goto=ads&do=edit&oj='.$ad['aid'].'>edit</a><br>';
  	}
  	$result = mysql_query('SELECT * FROM photos WHERE aid='.$ad['aid']);
  	while($photo = mysql_fetch_array($result)) {
  		echo '<img src = "photos/'.$ad['aid'].'/'.$photo['filename'].'" alt = "'.$photo['filename'].'"><br>';
  	}
  }
  else {
  	$header->add(_NOTFOUND);
		include("header.php");
  	echo "Δεν υπάρχει η αγγελία";
  }*/
}
else {
	$header->add(_SEARCH);
	$header->addjs("core/favorite.js");
	$header->addjs("core/search.js");
	include("header.php");
	//echo 'selida me search kai ajax';
	
	$adstemp = new template();
	$adstemp->load(array(
						  	"ISUSER" => $_SESSION["uid"],
						  	"NOTLOGEDIN" => _NOTLOGEDIN,
						  	"NOTADDED" => _NOTADDED,
						  	"SUCCSESS" => isset($aid),
						  	"SUCCSESSFULYADDED" => _SUCCSESSFULYADDED,
						  	"CATEGORY" => _CATEGORY,
						  	"COST" => _COST,
						  	"AREA" => _AREA,
						  	"YEAR" => _YEAR,
						  	"SUPPLIES" => _SUPPLIES,
						  	"FOR" => _FOR,
						  	"SELL" => _SELL,
						  	"RENT" => _RENT,
						  	"PC" => _PC,
						  	"ADDRESS" => _ADDRESS,
						  	"NUM" => _NUM,
						  	"PHOTOS" => _PHOTOS,
						  	"MORE" => _MORE,
						  	"SUBMIT" => _SUBMIT
						  ));
	$result = mysql_query('SELECT * FROM categories');
	while($cat = mysql_fetch_array($result)) {
		$adstemp->load(array("CATEGORIES" => array(array(
																									"ID" => $cat['cid'],
						 																			"NAME" => $cat['type']
						 																		))
	  								));
	}
		  
	$result = mysql_query('SELECT * FROM supplies');
	while($sup = mysql_fetch_array($result)) {
		$adstemp->load(array("SUPPLY" => array(array(
																									"ID" => $sup['sid'],
						 																			"NAME" => $sup['supply']
						 																		))
	  								));
	}
	$adstemp->draw('ads.html');
}

?>