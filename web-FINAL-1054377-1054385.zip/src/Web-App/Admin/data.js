function deleteData() {
	let r = confirm("Delete Data?");
	if (r == true) {
		fetch("http://localhost:80/index.html/testing-backend/delete.php", {
			method: "POST",
			headers: { "Content-Type": "application/json" }
		}).then(res => alert("data deleted"));
	}
}
