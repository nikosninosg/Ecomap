<?php
session_start();

$conn = new mysqli('localhost','myuser','!2345sS8','ecomap');

if ($conn->connect_error) 
{
    die(json_encode(array("status"=>"fail","msg"=>"database connection error")));
}

$json = file_get_contents('php://input');
$creds = json_decode($json,true);

try{
$text = $creds["mail"];
$key = $creds["password"];
$cipher = "aes-128-ctr";
$iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher));;
$id = openssl_encrypt($text, $cipher, $key, 0, $iv);
}catch(Exception $e){
    die(json_encode(array("status"=>"fail","msg"=>$e->getMessage())));
}

$sql = "select id from users where username='{$creds['username']}' and password='{$creds['password']}'";

$result = $conn->query($sql);
$row = $result->fetch_assoc();

if(!is_null($row)){
	die(json_encode(array("msg"=>"User exists!","status"=>"fail")));
}else{
	$sql = "insert into users(id,username,password,email) values('{$id}','{$creds["username"]}','{$creds['password']}','{$creds['mail']}')";

	if ($conn->query($sql) === TRUE) {
		echo json_encode(array("msg"=>$creds,"status"=>"success"));
		$_SESSION["id"] = $id;
		

	} else {
		die(json_encode(array("msg"=>$conn->error,"status"=>"fail")));
	}

}

?>
