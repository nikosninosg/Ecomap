<?php
session_start();

$conn = new mysqli('localhost','myuser','!2345sS8','ecomap');

if ($conn->connect_error) 
{
    die(json_encode(array("status"=>"fail","msg"=>"database connection error")));
}


$id = $_SESSION["id"];
$last = array();
$date = array();

try{
	$sql = "select lastUpload from users where id = $id";

	$result = $conn->query($sql);	

	if($result->num_rows > 0){
		$last["has"] = "true";
		$last["lastUpload"] = $result->fetch_assoc()["lastUpload"];

		$sql = "select min(timestampMs) as min , max(timestampMs as max) from loactionData where userId = $id";

		$result = $conn->query($sql);	
		$date["first"] == $result->fetch_assoc()["min"];
		$date["last"] == $result->fetch_assoc()["max"];
	}else{
		$last["has"] ="false";
	}	

	echo(json_encode(array("last"=>$last,"date"=>$date)));

}catch(Exception $e){

	die(json_encode(array("status"=>"fail","msg"=>$e->getMessage())));
}




?>
