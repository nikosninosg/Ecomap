<?php

$conn = new mysqli('localhost','myuser','!2345sS8','ecomap');

if (mysqli_connect_error()) 
{
    die(json_encode(array("status"=>"fail","msg"=>"database connection error")));
}

mysqli_query($conn,"SET sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''))");

$sql_a = "select username, userId, activity_type, COUNT(*) as count from locationData inner join users on users.id=locationData.userId group by activity_type";

$result = $conn->query($sql_a);

if($result->num_rows > 0) {
	$row = $result -> fetch_assoc();
	$json = json_encode($row);
	echo $json;
}else{
echo json_encode(array("status"=>"fail","msg"=>$conn->error));
}


?>
