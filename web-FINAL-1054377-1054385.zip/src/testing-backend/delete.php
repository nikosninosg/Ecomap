
<?php
session_start();

$conn = new mysqli('localhost','myuser','!2345sS8','ecomap');

if ($conn->connect_error) 
{
    die(json_encode(array("status"=>"fail","msg"=>"database connection error")));
}


$sql = "call deleteData()";

$result = $conn->query($sql);

?>
