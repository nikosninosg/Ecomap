<?php
session_start();
$id = $_SESSION["id"];

//Connection 
$conn = new mysqli('localhost','myuser','!2345sS8','ecomap');

if ($conn->connect_error) 
{
    die(json_encode(array("status"=>"fail","msg"=>"database connection error")));
}
mysqli_query($conn,'SET CHARACTER SET utf8;');
mysqli_query($conn,'SET COLLATION_CONNECTION=utf8_general_ci;');


//Read the JSON file and stored in a variable
$json = file_get_contents('php://input');

//Convert JSON string into PHP array format
$data = json_decode($json, true); 
$data = $data["locations"];

$len = sizeof($data);
for ($i = 0; $i < $len; $i++) {

	$temp_data = $data[$i];
	if(array_key_exists("activity",$temp_data) && count($temp_data["activity"]) > 0 ){
		$activity = $temp_data["activity"][0];
		$activity_array = array(
			"activity_timestampMs" => $activity["timestampMs"],
			"activity_type" => $activity["activity"][0]["type"],
			"activity_confidence" => $activity["activity"][0]["confidence"],
		);
	} else {
		$activity_array = array(
			"activity_type" => "NULL"
		);
	}
	unset($temp_data["activity"]);
	$fields = "`" . implode("`,`",array_keys($temp_data)) ."`,`". implode("`,`",array_keys($activity_array)). "`";
	$values = "'" . implode("','",array_values($temp_data)) ."','". implode("','",array_values($activity_array)). "'";

	$sql = " INSERT INTO `locationData`(`locationID`, `userId`, $fields) VALUES (uuid(),'$id',$values)";

	//die(json_encode(array("data"=>$temp_data,"sql"=>$sql,"status"=>"fail")));
	if(!$result = $conn->query($sql)){ 
		echo json_encode(array("quer"=>$sql,"sql"=>$conn->error,"msg"=>"problem inserting","status"=>"entryFail"));
	}

} //END for
$sql ="update users set lastUpload = curdate() where id = '$id'";
if(!$result = $conn->query($sql)){ 
	die(json_encode(array("quer"=>$sql,"sql"=>$conn->error,"msg"=>"problem inserting","status"=>"fail")));
}

echo json_encode(array("quer"=>$sql,"msg"=>"Succesful Upload","status"=>"success"));

?>
