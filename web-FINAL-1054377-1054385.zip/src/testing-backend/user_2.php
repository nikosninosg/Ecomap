<?php
session_start();

$conn = new mysqli('localhost','myuser','!2345sS8','ecomap');

if (mysqli_connect_error()) 
{
    die('Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
}

$id = $_SESSION["id"];

//a score
mysqli_query($conn,'SET CHARACTER SET utf8;');
mysqli_query($conn,'SET COLLATION_CONNECTION=utf8_general_ci;');

$sql = "select lastUpload from users where id = '$id'";

$res = mysqli_query($conn, $sql) or die(json_encode(array("status"=>"fail","msg"=>mysqli_error($conn))));
$last_up = mysqli_fetch_array($res)[0];

$sql = "select min(a.timestampCONV) as min, max(a.timestampCONV) as max from (select * from locationData inner join timestampMs on locationData.locationID = timestampMs.locationData where locationData.userId = '$id') a";

$res = mysqli_query($conn, $sql) or die(json_encode(array("status"=>"fail","msg"=>mysqli_error($conn))));
$row = mysqli_fetch_assoc($res);
$first_dt = $row["min"];
$last_dt = $row["max"];
$nums = array();
$scores = array();


$sql = "select id,username from users";
$res = mysqli_query($conn, $sql) or die(json_encode(array("status"=>"fail","msg"=>mysqli_error($conn))));

$users=array();
while($user=mysqli_fetch_assoc($res)){
	array_push($users, array($user["id"],$user["username"]));
	if($user["id"] == $id){
		$usrname = $user["username"];
	}
}


foreach($users as &$usr){
	$sql = "select activity_type, count(*) as cnt from locationData where userId = '{$usr[0]}' group by activity_type";
	$res = mysqli_query($conn, $sql) or die(json_encode(array("sql"=>$sql,"status"=>"fail","msg"=>mysqli_error($conn))));
	$temp_arr = array();
	while($act=mysqli_fetch_assoc($res)){
		$temp_arr[$act["activity_type"]] = $act["cnt"];
	}
	$nums[$usr[1]] = $temp_arr;
}

foreach($nums as $key => $num){
	$scr = ( $num["ON_BICYCLE"] + $num["ON_FOOT"] + $num["RUNNING"] + $num["WALKING"] )/($num["IN_VECHILE"] + 1);
	$scores[$key]= $scr;
}
arsort($scores,SORT_NUMERIC);
$scores = array_slice($scores,0,3);
$usrscore = $scores[$usrname];
echo json_encode(array("username"=>$usrname,"usr"=>$usrscore,"scores"=>$scores,"nums"=>$nums,"status"=>"success","last_up"=>$last_up,"first_dt"=>$first_dt,"last_dt"=>$last_dt));

?>
