<?php
session_start();

$conn = new mysqli('localhost','myuser','!2345sS8','ecomap');

if ($conn->connect_error) 
{
    die(json_encode(array("status"=>"fail","msg"=>"database connection error")));
}

$json = file_get_contents('php://input');
$creds = json_decode($json,true);


$sql = "select id,isAdmin from users where username='{$creds["username"]}'and password='{$creds["password"]}'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

if(is_null($row)){
	die(json_encode(array("sql"=>$sql,"msg"=>"User doesn't exist!","status"=>"fail")));
}else{
	$_SESSION["id"] = $row["id"];
	$_SESSION["isAdmin"] = $row["isAdmin"];
	if($row["isAdmin"]){
		$response = array("status"=>"success","isAdmin"=>true);
	}else{
		$response = array("status"=>"success","isAdmin"=>false);
	}
	echo json_encode($response);
}

?>

